// ============================================================
// MudClient – I4: Vlastní klientský program pro MUD server
// ============================================================
// Použití: dotnet run [host] [port]
// Příklad: dotnet run localhost 4000
//          dotnet run 192.168.1.5 4000
// ============================================================

using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        string host = args.Length > 0 ? args[0] : "localhost";
        int port = args.Length > 1 && int.TryParse(args[1], out int p) ? p : 4000;

        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        Console.WriteLine($"=== MUD Klient – Šípková Tulipánka ===");
        Console.WriteLine($"Připojuji se na {host}:{port}...");
        Console.WriteLine("Odpojeníz: napište 'konec' nebo stiskněte Ctrl+C\n");

        using var cts = new CancellationTokenSource();

        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            cts.Cancel();
        };

        try
        {
            using TcpClient client = new TcpClient();
            await client.ConnectAsync(host, port, cts.Token);
            Console.WriteLine("Připojeno!\n");

            using NetworkStream stream = client.GetStream();
            using StreamReader reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
            using StreamWriter writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true)
            {
                AutoFlush = true,
                NewLine = "\r\n"
            };

            // Task: číst data ze serveru a tisknout do konzole
            Task readTask = Task.Run(async () =>
            {
                try
                {
                    while (!cts.Token.IsCancellationRequested)
                    {
                        string? line = await reader.ReadLineAsync(cts.Token);
                        if (line == null) break;
                        Console.WriteLine(line);
                    }
                }
                catch (OperationCanceledException) { }
                catch (Exception ex) when (ex is IOException or ObjectDisposedException)
                {
                    Console.WriteLine("\n[Spojení ukončeno serverem]");
                }
                finally
                {
                    cts.Cancel();
                }
            }, cts.Token);

            // Hlavní smyčka: číst vstup z konzole a posílat serveru
            try
            {
                while (!cts.Token.IsCancellationRequested)
                {
                    string? input = await Task.Run(() =>
                    {
                        try { return Console.ReadLine(); }
                        catch { return null; }
                    }, cts.Token);

                    if (input == null || cts.Token.IsCancellationRequested) break;

                    await writer.WriteLineAsync(input.AsMemory(), cts.Token);
                }
            }
            catch (OperationCanceledException) { }

            await readTask.WaitAsync(TimeSpan.FromSeconds(2));
        }
        catch (SocketException ex)
        {
            Console.WriteLine($"[Chyba] Nepodařilo se připojit: {ex.Message}");
            Console.WriteLine($"Zkontroluj zda server běží na {host}:{port}");
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("\nOdpojeno.");
        }

        Console.WriteLine("Nashledanou!");
    }
}
