using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

// Automatický tester MUD serveru – simululuje připojení hráčů a testuje funkce
class MudTester
{
    static int _passed = 0;
    static int _failed = 0;

    // Normalizace diakritiky pro porovnání (stejná logika jako v TextHelper)
    static string Norm(string s)
    {
        var map = new[] {
            ("á","a"),("č","c"),("ď","d"),("é","e"),("ě","e"),("í","i"),("ň","n"),
            ("ó","o"),("ř","r"),("š","s"),("ť","t"),("ú","u"),("ů","u"),("ý","y"),("ž","z"),
            ("Á","A"),("Č","C"),("Ď","D"),("É","E"),("Ě","E"),("Í","I"),("Ň","N"),
            ("Ó","O"),("Ř","R"),("Š","S"),("Ť","T"),("Ú","U"),("Ů","U"),("Ý","Y"),("Ž","Z"),
        };
        foreach (var (from, to) in map) s = s.Replace(from, to);
        return s.ToLower();
    }

    // Přečte dostupné řádky ze serveru (s timeoutem)
    static async Task<string> ReadAll(StreamReader reader, int timeoutMs = 1500)
    {
        var sb = new StringBuilder();
        var cts = new CancellationTokenSource(timeoutMs);
        try
        {
            while (true)
            {
                string? line = await reader.ReadLineAsync(cts.Token);
                if (line == null) break;
                sb.AppendLine(line);
            }
        }
        catch (OperationCanceledException) { }
        return sb.ToString();
    }

    // Pošle příkaz a přečte odpověď
    static async Task<string> Send(StreamWriter w, StreamReader r, string cmd, int waitMs = 1200)
    {
        await w.WriteLineAsync(cmd);
        await Task.Delay(waitMs);
        return await ReadAll(r, 800);
    }

    // Ověření – normalizuje obě strany před porovnáním
    static void Check(string testName, string output, string expectedSubstring)
    {
        string normOutput = Norm(output);
        string normExpected = Norm(expectedSubstring);
        bool ok = normOutput.Contains(normExpected);
        string status = ok ? "PASS" : "FAIL";
        if (ok) _passed++; else _failed++;
        Console.ForegroundColor = ok ? ConsoleColor.Green : ConsoleColor.Red;
        if (ok)
        {
            Console.WriteLine($"  [PASS] {testName}");
        }
        else
        {
            string preview = output.Trim();
            if (preview.Length > 140) preview = preview[..140] + "...";
            Console.WriteLine($"  [FAIL] {testName}");
            Console.WriteLine($"         Ocekavano: '{expectedSubstring}'");
            Console.WriteLine($"         Dostano:   '{preview}'");
        }
        Console.ResetColor();
    }

    // Přihlásí hráče a vrátí akumulovaný výstup po přihlášení
    static async Task<string> Login(StreamWriter w, StreamReader r, string user, string pwd)
    {
        await ReadAll(r, 2500); // welcome
        // Posíláme username – server odpoví výzvou k heslu
        await w.WriteLineAsync(user);
        await Task.Delay(600);
        var afterUser = await ReadAll(r, 800);
        // Posíláme heslo
        await w.WriteLineAsync(pwd);
        await Task.Delay(700);
        var afterPwd = await ReadAll(r, 1200);
        return afterUser + afterPwd;
    }

    static async Task RunSession(string label, Func<StreamWriter, StreamReader, Task> scenario)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"\n=== {label} ===");
        Console.ResetColor();
        try
        {
            using var client = new TcpClient();
            await client.ConnectAsync("127.0.0.1", 4000);
            using var stream = client.GetStream();
            using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
            using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true)
                { AutoFlush = true, NewLine = "\r\n" };
            await scenario(writer, reader);
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  [CHYBA SPOJENI] {ex.Message}");
            Console.ResetColor();
            _failed++;
        }
    }

    static async Task Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine("╔════════════════════════════════════════╗");
        Console.WriteLine("║  AUTOMATICKÝ TEST – Šípková Tulipánka  ║");
        Console.WriteLine("╚════════════════════════════════════════╝");
        await Task.Delay(300);

        // ── TEST 1: Login + základní příkazy ────────────────────────────
        await RunSession("TEST 1 – Login test_player / Test123 + základní příkazy", async (w, r) =>
        {
            string loginOut = await Login(w, r, "test_player", "Test123");
            Check("T1-01 Uvitaci zprava obsahuje 'Vitej'",         loginOut, "Vitej");
            Check("T1-02 Prihlaseni – jmeno hrace zobrazeno",      loginOut, "test_player");
            Check("T1-03 Uvodni mistnost – Farma nebo ulozena",    loginOut, "==+");  // zobrazí místnost

            // Prozkoumej
            string look = await Send(w, r, "prozkoumej", 1000);
            Check("T1-04 Prozkoumej – vychody",    look, "Vychody");
            Check("T1-05 Prozkoumej – predmety",   look, "Predmety");
            Check("T1-06 Prozkoumej – postavy",    look, "Postavy");

            // Inventár
            string inv = await Send(w, r, "inventar", 800);
            Check("T1-07 Inventar – prikaz funguje", inv, "Inventar");

            // Penize
            string gold = await Send(w, r, "penize", 800);
            Check("T1-08 Penize – zobrazeni zlata", gold, "zlatych");

            // Pomoc
            string help = await Send(w, r, "pomoc", 1000);
            Check("T1-09 Pomoc – obsahuje 'jdi'",    help, "jdi");
            Check("T1-10 Pomoc – obsahuje 'konec'",  help, "konec");
            Check("T1-11 Pomoc – obsahuje 'mluv'",   help, "mluv");

            // Statistiky
            string stats = await Send(w, r, "statistiky", 800);
            Check("T1-12 Statistiky – zobrazeni", stats, "Hrac");

            // Neznámý příkaz
            string unknown = await Send(w, r, "letim", 800);
            Check("T1-13 Neznamy prikaz – chybova hlaska", unknown, "neznam");

            // Konec
            string quit = await Send(w, r, "konec", 800);
            Check("T1-14 Konec – rozlouceni", quit, "Nashledanou");
        });

        await Task.Delay(600);

        // ── TEST 2: Špatné heslo ─────────────────────────────────────────
        await RunSession("TEST 2 – Spatne heslo (3 pokusy → odpojeni)", async (w, r) =>
        {
            await ReadAll(r, 2000);
            await w.WriteLineAsync("test_player");
            await Task.Delay(500);
            await ReadAll(r, 600);

            // 1. pokus
            string a1 = await Send(w, r, "SpatneHeslo1", 700);
            Check("T2-01 1. spatny pokus – hlaska", a1, "Spatne heslo");

            // 2. pokus
            string a2 = await Send(w, r, "SpatneHeslo2", 700);
            Check("T2-02 2. spatny pokus – hlaska", a2, "Spatne heslo");

            // 3. pokus – zamítnutí
            string a3 = await Send(w, r, "SpatneHeslo3", 1200);
            Check("T2-03 3. pokus – odpojeni serveru", a3, "mnoho spatnych");
        });

        await Task.Delay(600);

        // ── TEST 3: Pohyb ────────────────────────────────────────────────
        await RunSession("TEST 3 – Pohyb (jdi, prozkoumej po pohybu)", async (w, r) =>
        {
            // Přihlásíme se a dostaneme se na Farmu
            await Login(w, r, "test_player", "Test123");

            // Navigujeme na Farmu přes aktuální polohu
            // Z Vesnice: jdi zapad → Les; z Lesa: jdi jih → Farma
            // Zkusíme se dostat na farmu (player může být kdekoli)
            await Send(w, r, "jdi zapad", 600);   // z Vesnice → Les; nebo chyba
            await Send(w, r, "jdi jih", 600);     // z Lesa → Farma; nebo chyba
            await Send(w, r, "jdi zapad", 600);   // z Farmy → Jezero; nebo chyba
            string room = await Send(w, r, "prozkoumej", 1000);

            // Pohyb sever z Farmy → Les
            await Send(w, r, "jdi zapad", 600);   // zpet na Farmu pokud na Jezero
            await Send(w, r, "jdi sever", 600);   // z Farmy → Les
            string inLes = await Send(w, r, "prozkoumej", 800);
            Check("T3-01 Pohyb – dostali jsme se do Lesa", inLes, "LES");

            // Pohyb vychod z Lesa → Vesnice
            string goEast = await Send(w, r, "jdi vychod", 900);
            Check("T3-02 Pohyb vychod – zprava o pohybu", goEast, "Jdes vychod");
            Check("T3-03 Pohyb vychod – Vesnice", goEast, "VESNICE");

            // Pohyb neexistujici smer
            string badDir = await Send(w, r, "jdi nowhere", 700);
            Check("T3-04 Neexistujici smer – chybova hlaska", badDir, "nevede");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 4: Předměty ─────────────────────────────────────────────
        await RunSession("TEST 4 – Predmety (vezmi / poloz / inventar)", async (w, r) =>
        {
            await Login(w, r, "test_player", "Test123");

            // Navigace na Farmu (kde je jablko)
            // z Vesnice: zapad→Les, jih→Farma; z Lesa: jih→Farma; z Farmy: jsme tam
            await Send(w, r, "jdi zapad", 600);  // les (z vesnice) nebo chyba
            await Send(w, r, "jdi jih", 700);    // farma

            // Zkontroluj, kde jsme
            string whereAmI = await Send(w, r, "prozkoumej", 800);

            // Musíme být na Farmě
            Check("T4-01 Jsme na Farme", whereAmI, "FARMA");

            // Vezmi jablko
            string take = await Send(w, r, "vezmi jablko", 800);
            Check("T4-02 Vezmi jablko – uspesne", take, "Vzal");

            // Inventár obsahuje jablko
            string inv = await Send(w, r, "inventar", 800);
            Check("T4-03 Inventar obsahuje jablko", inv, "jablko");

            // Polož jablko
            string drop = await Send(w, r, "poloz jablko", 800);
            Check("T4-04 Poloz jablko – uspesne", drop, "Polozil");

            // Inventár je prázdný (pro test_player, pokud není uložen jinak)
            string inv2 = await Send(w, r, "inventar", 800);
            Check("T4-05 Inventar po polozeni – neobsahuje jablko", inv2, "Inventar");

            // Vezmi neexistující predmet
            string takeBad = await Send(w, r, "vezmi drak", 700);
            Check("T4-06 Vezmi neexistujici – chyba", takeBad, "nevidim");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 5: Kvíz ────────────────────────────────────────────────
        await RunSession("TEST 5 – Kviz s NPC (Zaba na Jezere)", async (w, r) =>
        {
            await Login(w, r, "test_player", "Test123");

            // Navigace na Jezero: Farma→zapad=Jezero; Vesnice→zapad=Les→jih=Farma→zapad=Jezero
            // Nejjednodušší cesta: z Farmy jdi zapad
            await Send(w, r, "jdi zapad", 600); // les (z vesnice) nebo jezero (z farmy)
            await Send(w, r, "jdi jih", 600);   // farma (z lesa) nebo hory (z jezera – nechceme)
            // Teď bychom měli být na Farmě nebo někde blízko
            await Send(w, r, "jdi zapad", 700); // jezero (z farmy)

            string atLake = await Send(w, r, "prozkoumej", 800);
            Check("T5-01 Jsme u Jezera", atLake, "JEZERO");

            // Mluv s Žábou
            string talk = await Send(w, r, "mluv Zaba", 800);
            Check("T5-02 Mluv Zaba – odpovida", talk, "Zaba");

            // Spusť kvíz
            string quizStart = await Send(w, r, "kviz Zaba", 1000);
            Check("T5-03 Kviz Zaba – spusten", quizStart, "Otazka");

            // Otázka 1: Kolik noh má pavouk? = 8
            string ans1 = await Send(w, r, "8", 1000);
            Check("T5-04 Spravna odpoved pavouk=8", ans1, "Spravne");

            // Přeskočení otázky 2
            string skip = await Send(w, r, "preskoc", 900);
            Check("T5-05 Preskoceni otazky", skip, "preskocena");

            // Otázka 3: Kolik vajec? = 300
            string ans3 = await Send(w, r, "300", 1000);
            Check("T5-06 Kviz dokoncen – souhrn", ans3, "Kviz konci");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 6: Obchod ───────────────────────────────────────────────
        await RunSession("TEST 6 – Obchod ve Vesnici", async (w, r) =>
        {
            await Login(w, r, "test_player", "Test123");

            // Pokud jsme v Lese nebo jinde, nejdeme do Vesnice
            // Navigace: jdi vychod z Lesa = Vesnice
            await Send(w, r, "jdi sever", 600);   // z Farmy → Les; nebo chyba
            await Send(w, r, "jdi vychod", 700);  // z Lesa → Vesnice

            // Shop mimo Vesnici – pokud někde jinde
            // Toto testujeme na Farmě v separátní session
            string shopInVesnice = await Send(w, r, "shop", 900);
            Check("T6-01 Shop ve Vesnici – zobrazen", shopInVesnice, "OBCHOD");
            Check("T6-02 Shop obsahuje klic bronzovy", shopInVesnice, "klic bronzovy");
            Check("T6-03 Shop obsahuje lektvar zdravi", shopInVesnice, "lektvar zdravi");
            Check("T6-04 Shop zobrazuje ceny", shopInVesnice, "zl.");

            // Koupit bez peněz
            string buyFail = await Send(w, r, "kup klic bronzovy", 800);
            Check("T6-05 Kup bez penez – chyba", buyFail, "Nemas dost zlata");

            // Shop mimo Vesnici (jdeme jinam)
            await Send(w, r, "jdi zapad", 600); // Les
            string shopOutside = await Send(w, r, "shop", 700);
            Check("T6-06 Shop mimo Vesnici – chyba", shopOutside, "jen ve Vesnici");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 7: Zamčená místnost ──────────────────────────────────────
        await RunSession("TEST 7 – Zamcena mistnost (Hrad bez klicu)", async (w, r) =>
        {
            await Login(w, r, "test_player", "Test123");

            // Do Lesa: sever z Farmy nebo vychod z Vesnice
            await Send(w, r, "jdi sever", 600);   // farma→les; nebo chyba z vesnice
            await Send(w, r, "jdi zapad", 600);   // vesnice→les; nebo les→hrad (blocked)

            // Pokus o vstup do Hradu
            string tryHrad = await Send(w, r, "jdi zapad", 900);
            Check("T7-01 Pokus o Hrad – zamcen", tryHrad, "zamceny");
            Check("T7-02 Hrad – vypis chybejicich klicu", tryHrad, "klic");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 8: NPC dialog + kvíz ────────────────────────────────────
        await RunSession("TEST 8 – NPC dialog a kviz (Myslivec v Lese)", async (w, r) =>
        {
            await Login(w, r, "test_player", "Test123");

            // Dostaneme se do Lesa
            await Send(w, r, "jdi sever", 600);  // farma→les; nebo jinak
            await Send(w, r, "jdi zapad", 600);  // vesnice→les; nebo les→hrad(block)

            // Prozkoumej – ověr že jsme v Lese
            string inLes = await Send(w, r, "prozkoumej", 900);
            if (!Norm(inLes).Contains("les"))
            {
                // zkus jinou cestu
                await Send(w, r, "jdi zapad", 600);
            }

            // Mluv s Myslivcem
            string mluv = await Send(w, r, "mluv Myslivec", 800);
            Check("T8-01 Mluv Myslivec – odpovida", mluv, "Myslivec");
            Check("T8-02 Tip na kviz zobrazen", mluv, "kviz");

            // Kvíz Myslivec
            string qs = await Send(w, r, "kviz Myslivec", 1000);
            Check("T8-03 Kviz Myslivec – spusten", qs, "Otazka 1");

            // Otázka 1: Kolik noh má jelen? = 4
            string q1 = await Send(w, r, "4", 900);
            Check("T8-04 Spravna odpoved – jelen=4", q1, "Spravne");

            // Otázka 2: lišče – přeskočíme
            await Send(w, r, "preskoc", 700);

            // Otázka 3: papoušek → železný klíč
            string q3 = await Send(w, r, "papousek", 1000);
            Check("T8-05 Spravna odpoved – klíč ziskan", q3, "klic zelezny");
            Check("T8-06 Kviz dokoncen", q3, "Kviz konci");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 9: Uložený stav saved_player ────────────────────────────
        await RunSession("TEST 9 – saved_player: obnova ulozeneho stavu", async (w, r) =>
        {
            string loginOut = await Login(w, r, "saved_player", "Save123");
            Check("T9-01 saved_player prihlasen", loginOut, "saved_player");
            Check("T9-02 Obnova mistnosti – Vesnice", loginOut, "VESNICE");

            string gold = await Send(w, r, "penize", 700);
            Check("T9-03 Obnova zlata (25)", gold, "25");

            string inv = await Send(w, r, "inventar", 800);
            Check("T9-04 Inventar – klic bronzovy obnoven", inv, "klic bronzovy");
            Check("T9-05 Inventar – pochoden obnovena", inv, "pochoden");

            await Send(w, r, "konec", 700);
        });

        await Task.Delay(600);

        // ── TEST 10: Registrace nového hráče ─────────────────────────────
        await RunSession("TEST 10 – Registrace new_player_002 (unikatni ucet)", async (w, r) =>
        {
            // Pošleme username
            await ReadAll(r, 2200);
            await w.WriteLineAsync("new_player_002");
            await Task.Delay(700);
            string notFoundMsg = await ReadAll(r, 1200);
            Check("T10-01 Ucet nenalezen – hlaska", notFoundMsg, "nenalezen");

            // Odpovíme "ano" na registraci
            await w.WriteLineAsync("ano");
            await Task.Delay(600);
            string pwdPrompt = await ReadAll(r, 1000);
            Check("T10-02 Vyzva k zadani hesla", pwdPrompt, "heslo");

            // Heslo
            await w.WriteLineAsync("New123");
            await Task.Delay(500);
            string confirmPrompt = await ReadAll(r, 1000);
            Check("T10-03 Vyzva k potvrzeni hesla", confirmPrompt, "Potvrdte");

            // Potvrzení
            await w.WriteLineAsync("New123");
            await Task.Delay(800);
            string created = await ReadAll(r, 1500);
            Check("T10-04 Ucet vytvoren", created, "vytvoren");
            Check("T10-05 Uvod do hry po registraci", created, "==+");

            await w.WriteLineAsync("konec");
            await Task.Delay(700);
        });

        await Task.Delay(600);

        // ── TEST 11: ghost_player odmítnutí registrace ───────────────────
        await RunSession("TEST 11 – ghost_player_999: odmitnuti registrace", async (w, r) =>
        {
            await ReadAll(r, 2000);
            await w.WriteLineAsync("ghost_player_999");
            await Task.Delay(600);
            string msg = await ReadAll(r, 1200);
            Check("T11-01 ghost_player – ucet nenalezen", msg, "nenalezen");

            // Odmítneme registraci
            await w.WriteLineAsync("ne");
            await Task.Delay(700);
            string bye = await ReadAll(r, 900);
            Check("T11-02 Odmitnutí – server reka Nashledanou", bye, "Nashledanou");
        });

        await Task.Delay(600);

        // ── TEST 12: Multi-player (2 hráči současně) ─────────────────────
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\n=== TEST 12 – Vice hracu soucasne (multi-player) ===");
        Console.ResetColor();

        try
        {
            // Oba hráče pošleme do Lesa paralelně
            // test_player: z Vesnice → jdi zapad → Les
            // saved_player: z Vesnice → jdi zapad → Les
            var t1 = Task.Run(async () =>
            {
                using var c = new TcpClient();
                await c.ConnectAsync("127.0.0.1", 4000);
                using var s = c.GetStream();
                using var r = new StreamReader(s, Encoding.UTF8);
                using var w = new StreamWriter(s, Encoding.UTF8) { AutoFlush = true, NewLine = "\r\n" };
                await Login(w, r, "test_player", "Test123");
                await Send(w, r, "jdi zapad", 700);   // → Les (z Vesnice)
                await Task.Delay(600);                 // počkáme na hráče 2
                string look = await Send(w, r, "prozkoumej", 1200);
                await w.WriteLineAsync("konec");
                await Task.Delay(500);
                return look;
            });

            await Task.Delay(600); // hráč 2 se připojí o něco pozdějí

            var t2 = Task.Run(async () =>
            {
                using var c = new TcpClient();
                await c.ConnectAsync("127.0.0.1", 4000);
                using var s = c.GetStream();
                using var r = new StreamReader(s, Encoding.UTF8);
                using var w = new StreamWriter(s, Encoding.UTF8) { AutoFlush = true, NewLine = "\r\n" };
                await Login(w, r, "saved_player", "Save123");
                await Send(w, r, "jdi zapad", 700);   // → Les (z Vesnice)
                await Task.Delay(200);
                string look = await Send(w, r, "prozkoumej", 1200);
                await w.WriteLineAsync("konec");
                await Task.Delay(500);
                return look;
            });

            string[] results = await Task.WhenAll(t1, t2);
            string p1Look = results[0];
            string p2Look = results[1];

            Check("T12-01 test_player je v Lese", p1Look, "LES");
            Check("T12-02 saved_player je v Lese", p2Look, "LES");
            Check("T12-03 test_player vidi saved_player v mistnosti", p1Look, "saved_player");
            Check("T12-04 saved_player vidi test_player v mistnosti", p2Look, "test_player");
            Check("T12-05 Oznaceni jako '(hrac)' v popisu mistnosti", p1Look, "(hrac)");
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  [FAIL] Multi-player vyjimka: {ex.Message}");
            Console.ResetColor();
            _failed += 5;
        }

        // ── VÝSLEDKY ─────────────────────────────────────────────────────
        Console.WriteLine();
        Console.WriteLine("╔════════════════════════════════════════╗");
        Console.WriteLine("║              VÝSLEDKY TESTŮ             ║");
        Console.WriteLine("╚════════════════════════════════════════╝");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"  PASS: {_passed}");
        Console.ForegroundColor = _failed > 0 ? ConsoleColor.Red : ConsoleColor.Green;
        Console.WriteLine($"  FAIL: {_failed}");
        Console.ResetColor();
        Console.WriteLine($"  CELKEM: {_passed + _failed}");
        double pct = _passed + _failed > 0 ? (double)_passed / (_passed + _failed) * 100 : 0;
        Console.ForegroundColor = pct >= 90 ? ConsoleColor.Green : pct >= 70 ? ConsoleColor.Yellow : ConsoleColor.Red;
        Console.WriteLine($"  USPESNOST: {pct:F0}%");
        Console.ResetColor();
    }
}
