// ============================================================
// AccountManager.cs – I3: Přihlášení a persistence hráče
// Hesla jsou hashována pomocí SHA-256.
// Stav hráče (poloha, inventář, zlato) se ukládá do players.json
// ============================================================

namespace MudServer;

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

// Data uložená pro jeden předmět v inventáři
public class SavedItem
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
}

// Kompletní save hráče
public class PlayerSave
{
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public int Gold { get; set; } = 0;
    public string RoomKey { get; set; } = "farma";
    public List<SavedItem> Inventory { get; set; } = new();
    public bool HasWon { get; set; } = false;
    public int QuizCorrect { get; set; } = 0;
    public int QuizTotal { get; set; } = 0;
}

public class AccountManager
{
    private static readonly string SaveFile = Path.Combine(
        AppDomain.CurrentDomain.BaseDirectory, "players.json");

    private readonly Dictionary<string, PlayerSave> _accounts
        = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _loggedIn
        = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _lock = new();

    private static readonly JsonSerializerOptions JsonOpts
        = new() { WriteIndented = true };

    public AccountManager()
    {
        Load();
        SeedTestAccounts();
    }

    // ---- Načítání z disku ----
    private void Load()
    {
        if (!File.Exists(SaveFile)) return;
        try
        {
            var list = JsonSerializer.Deserialize<List<PlayerSave>>(
                File.ReadAllText(SaveFile)) ?? new();
            foreach (var acc in list)
                _accounts[acc.Username] = acc;
            Logger.Log($"[Účty] Načteno {_accounts.Count} účtů z {SaveFile}");
        }
        catch (Exception ex)
        {
            Logger.Log($"[Účty] Chyba při načítání: {ex.Message}");
        }
    }

    // ---- Uložení všech účtů na disk ----
    private void PersistAll()
    {
        try
        {
            File.WriteAllText(SaveFile,
                JsonSerializer.Serialize(_accounts.Values.ToList(), JsonOpts));
        }
        catch (Exception ex)
        {
            Logger.Log($"[Účty] Chyba při ukládání: {ex.Message}");
        }
    }

    // ---- Testovací účty (požadovány test.docx) ----
    private void SeedTestAccounts()
    {
        bool changed = false;
        if (!_accounts.ContainsKey("test_player"))
        {
            _accounts["test_player"] = new PlayerSave
            {
                Username = "test_player",
                PasswordHash = HashPassword("Test123")
            };
            changed = true;
        }
        if (!_accounts.ContainsKey("saved_player"))
        {
            _accounts["saved_player"] = new PlayerSave
            {
                Username = "saved_player",
                PasswordHash = HashPassword("Save123"),
                Gold = 25,
                RoomKey = "vesnice",
                Inventory = new List<SavedItem>
                {
                    new SavedItem { Name = "klíč bronzový", Description = "Jeden ze tří klíčů pro vstup do hradu." },
                    new SavedItem { Name = "pochodeň", Description = "Světlo do tmy. Hoří dlouho." }
                }
            };
            changed = true;
        }
        if (changed) PersistAll();
    }

    // ---- Hashování hesla ----
    public static string HashPassword(string password)
        => Convert.ToHexString(
            SHA256.HashData(Encoding.UTF8.GetBytes(password))).ToLower();

    // ---- Veřejné metody ----
    public bool AccountExists(string username)
    {
        lock (_lock) return _accounts.ContainsKey(username);
    }

    public bool IsLoggedIn(string username)
    {
        lock (_lock) return _loggedIn.Contains(username);
    }

    public bool TryLogin(string username, string password)
    {
        lock (_lock)
        {
            if (!_accounts.TryGetValue(username, out var acc)) return false;
            if (acc.PasswordHash != HashPassword(password)) return false;
            _loggedIn.Add(username);
            Logger.Log($"[Přihlášení] Hráč '{username}' se přihlásil.");
            return true;
        }
    }

    public void Logout(string username)
    {
        lock (_lock)
        {
            _loggedIn.Remove(username);
            Logger.Log($"[Přihlášení] Hráč '{username}' se odhlásil.");
        }
    }

    public bool Register(string username, string password)
    {
        lock (_lock)
        {
            if (_accounts.ContainsKey(username)) return false;
            _accounts[username] = new PlayerSave
            {
                Username = username,
                PasswordHash = HashPassword(password)
            };
            PersistAll();
            Logger.Log($"[Účty] Nový účet: '{username}'");
            return true;
        }
    }

    // Vrátí kopii save dat (aby nedocházelo ke sdílení reference)
    public PlayerSave? GetSave(string username)
    {
        lock (_lock)
        {
            if (!_accounts.TryGetValue(username, out var s)) return null;
            return DeepCopy(s);
        }
    }

    // Uloží aktuální stav hráče
    public void UpdateSave(PlayerSave save)
    {
        lock (_lock)
        {
            _accounts[save.Username] = save;
            PersistAll();
        }
    }

    private static PlayerSave DeepCopy(PlayerSave s) => new()
    {
        Username = s.Username,
        PasswordHash = s.PasswordHash,
        Gold = s.Gold,
        RoomKey = s.RoomKey,
        Inventory = s.Inventory
            .Select(i => new SavedItem { Name = i.Name, Description = i.Description })
            .ToList(),
        HasWon = s.HasWon,
        QuizCorrect = s.QuizCorrect,
        QuizTotal = s.QuizTotal
    };
}
