// ============================================================
// Logger.cs – I2: Logování s časovými značkami do souboru
// ============================================================

namespace MudServer;

public static class Logger
{
    private static readonly string LogFile = Path.Combine(
        AppDomain.CurrentDomain.BaseDirectory, "server.log");
    private static readonly object _lock = new();

    public static void Log(string message)
    {
        string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}";
        Console.WriteLine(line);
        lock (_lock)
        {
            try { File.AppendAllText(LogFile, line + Environment.NewLine); }
            catch { }
        }
    }
}
