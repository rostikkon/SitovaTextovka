// ============================================================
// Program.cs – Vstupní bod aplikace
// ============================================================

using System;
using System.Threading;
using System.Threading.Tasks;
using MudServer;

class Program
{
    static async Task Main(string[] args)
    {
        int port = args.Length > 0 && int.TryParse(args[0], out int p) ? p : 4000;

        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Logger.Log("=== MUD Server – Šípková Tulipánka ===");
        Logger.Log($"Spouštím server na portu {port}...");
        Logger.Log("Připoj se přes: PuTTY / telnet localhost " + port);
        Logger.Log("Zastav server: Ctrl+C");

        // I3 – Inicializace správce účtů
        AccountManager accounts = new AccountManager();

        // I1 – Inicializace herního světa (načítá world.json pokud existuje)
        GameWorld world = new GameWorld();

        // Spuštění TCP serveru
        MudTcpServer server = new MudTcpServer(port, world, accounts);

        using CancellationTokenSource cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            Logger.Log("\nZastavuji server...");
            cts.Cancel();
        };

        await server.StartAsync(cts.Token);
        Logger.Log("Server zastaven.");
    }
}
