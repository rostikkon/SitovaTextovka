// ============================================================
// WorldDto.cs – I1: DTO třídy pro deserializaci world.json
// ============================================================

namespace MudServer;

// Kořenový objekt world.json
public class WorldDto
{
    public string StartRoom { get; set; } = "farma";
    public string[] HradKeys { get; set; } = Array.Empty<string>();
    public List<RoomDto> Rooms { get; set; } = new();
    public ShopDto Shop { get; set; } = new();
}

public class RoomDto
{
    public string Key { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public int RequiredKeys { get; set; } = 0;
    public Dictionary<string, string> Exits { get; set; } = new();
    public List<ItemDto> Items { get; set; } = new();
    public List<NpcDto> Npcs { get; set; } = new();
}

public class ItemDto
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
}

public class NpcDto
{
    public string Name { get; set; } = "";
    public string Greeting { get; set; } = "";
    public List<QuestionDto> Questions { get; set; } = new();
}

public class QuestionDto
{
    public string Text { get; set; } = "";
    public string Answer { get; set; } = "";
    public int Reward { get; set; } = 0;
    public ItemDto? ItemReward { get; set; } = null;
}

public class ShopDto
{
    public List<ShopItemDto> Items { get; set; } = new();
}

public class ShopItemDto
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public int Price { get; set; } = 0;
}
