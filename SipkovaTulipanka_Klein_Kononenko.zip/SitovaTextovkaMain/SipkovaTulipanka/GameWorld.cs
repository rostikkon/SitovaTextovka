// ============================================================
// GameWorld.cs
// ============================================================

namespace MudServer;

using System.Text;
using System.Text.Json;

// ------ POMOCNÁ TŘÍDA: normalizace textu bez diakritiky ------
public static class TextHelper
{
    private static readonly (string From, string To)[] DiacriticMap =
    {
        ("á","a"),("č","c"),("ď","d"),("é","e"),("ě","e"),
        ("í","i"),("ň","n"),("ó","o"),("ř","r"),("š","s"),
        ("ť","t"),("ú","u"),("ů","u"),("ý","y"),("ž","z"),
        ("Á","A"),("Č","C"),("Ď","D"),("É","E"),("Ě","E"),
        ("Í","I"),("Ň","N"),("Ó","O"),("Ř","R"),("Š","S"),
        ("Ť","T"),("Ú","U"),("Ů","U"),("Ý","Y"),("Ž","Z"),
    };

    public static string Normalize(string s)
    {
        foreach (var (from, to) in DiacriticMap)
            s = s.Replace(from, to);
        return s.ToLower();
    }

    public static bool Match(string a, string b)
        => Normalize(a).Contains(Normalize(b));
}

// ------ PŘEDMĚT -----------------------------------------------
public class Item
{
    public string Name { get; }
    public string Description { get; }

    public Item(string name, string description)
    {
        Name = name;
        Description = description;
    }
}

// ------ SHOP ITEM ---------------------------------------------
public class ShopItem
{
    public string Name { get; }
    public string Description { get; }
    public int Price { get; }

    public ShopItem(string name, string description, int price)
    {
        Name = name;
        Description = description;
        Price = price;
    }
}

// ------ OTÁZKA PRO NPC KVÍZ ----------------------------------
public class Question
{
    public string Text { get; }
    public string Answer { get; }
    public int Reward { get; }
    public Item? ItemReward { get; }

    public Question(string text, string answer, int reward, Item? itemReward = null)
    {
        Text = text;
        Answer = TextHelper.Normalize(answer);
        Reward = reward;
        ItemReward = itemReward;
    }

    public bool Check(string playerAnswer)
        => TextHelper.Normalize(playerAnswer).Trim() == Answer;
}

// ------ NPC ---------------------------------------------------
public class Npc
{
    public string Name { get; }
    private readonly string _greeting;
    public List<Question> Questions { get; } = new();

    public Npc(string name, string greeting)
    {
        Name = name;
        _greeting = greeting;
    }

    public string Speak() => $"{Name} říká: \"{_greeting}\"";
    public bool HasQuiz => Questions.Count > 0;
}

// ------ MÍSTNOST ----------------------------------------------
public class Room
{
    public string Key { get; set; } = "";   // klíč pro ukládání polohy
    public string Name { get; }
    public string Description { get; }
    public Dictionary<string, Room> Exits { get; } = new();
    public List<Item> Items { get; } = new();
    public List<Npc> Npcs { get; } = new();
    public int RequiredKeys { get; set; } = 0;

    public Room(string key, string name, string description)
    {
        Key = key;
        Name = name;
        Description = description;
    }

    public void AddExit(string direction, Room target)
        => Exits[direction] = target;

    public string Describe(IEnumerable<string> otherPlayerNames)
    {
        var sb = new StringBuilder();

        sb.AppendLine($"\n+== {Name.ToUpper()} ==+");
        sb.AppendLine(Description);

        sb.AppendLine("\n[ Východy ]");
        if (Exits.Count == 0)
            sb.AppendLine("  Žádné východy.");
        else
            foreach (var exit in Exits)
                sb.AppendLine($"  {exit.Key,8} -> {exit.Value.Name}");

        sb.AppendLine("\n[ Předměty ]");
        if (Items.Count == 0)
            sb.AppendLine("  Nic tu neleží.");
        else
            foreach (var item in Items)
                sb.AppendLine($"  * {item.Name}");

        sb.AppendLine("\n[ Postavy ]");
        var allChars = new List<string>();
        allChars.AddRange(Npcs.Select(n => n.Name + (n.HasQuiz ? " (kvíz)" : "") + " (NPC)"));
        allChars.AddRange(otherPlayerNames.Select(n => n + " (hráč)"));

        if (allChars.Count == 0)
            sb.AppendLine("  Nikdo tu není.");
        else
            foreach (var c in allChars)
                sb.AppendLine($"  * {c}");

        return sb.ToString();
    }
}

// ------ SHOP --------------------------------------------------
public class Shop
{
    public string Name { get; } = "Obchod u Vesničana";
    public List<ShopItem> Items { get; } = new();

    public string Describe()
    {
        var sb = new StringBuilder();
        sb.AppendLine("\n+== OBCHOD ==+");
        sb.AppendLine("Zboží na prodej (příkaz: kup <název>):");
        foreach (var item in Items)
            sb.AppendLine($"  * {item.Name,-22} – {item.Price} zl. | {item.Description}");
        return sb.ToString();
    }
}

// ------ HERNÍ SVĚT --------------------------------------------
public class GameWorld
{
    private readonly Dictionary<string, Room> _rooms = new();
    private readonly Dictionary<string, Player> _players = new();
    private readonly object _playersLock = new();

    public Room StartRoom { get; private set; } = null!;
    public Shop Shop { get; } = new Shop();

    // Klíče potřebné pro vstup do Hradu – nastavitelné z JSON
    public string[] HradKeys { get; private set; }
        = { "klic bronzovy", "klic zelezny", "klic stribrny" };

    public GameWorld()
    {
        string jsonPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "world.json");

        if (File.Exists(jsonPath))
        {
            try
            {
                LoadFromJson(jsonPath);
                Logger.Log($"[Svět] Herní svět načten z {jsonPath}");
                return;
            }
            catch (Exception ex)
            {
                Logger.Log($"[Svět] Chyba při načítání JSON: {ex.Message}. Používám výchozí svět.");
            }
        }
        else
        {
            Logger.Log("[Svět] world.json nenalezen. Používám výchozí svět.");
        }

        BuildWorld();
        StartRoom = _rooms["farma"];
    }

    // =========================================================
    // I1 – Načítání herního světa z JSON souboru
    // =========================================================
    private void LoadFromJson(string path)
    {
        var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var dto = JsonSerializer.Deserialize<WorldDto>(File.ReadAllText(path), opts)
            ?? throw new Exception("Prázdný nebo neplatný world.json");

        if (dto.HradKeys.Length > 0)
            HradKeys = dto.HradKeys;

        // Fáze 1: vytvořit všechny místnosti
        foreach (var rd in dto.Rooms)
        {
            var room = new Room(rd.Key, rd.Name, rd.Description)
            {
                RequiredKeys = rd.RequiredKeys
            };

            foreach (var id in rd.Items)
                room.Items.Add(new Item(id.Name, id.Description));

            foreach (var nd in rd.Npcs)
            {
                var npc = new Npc(nd.Name, nd.Greeting);
                foreach (var qd in nd.Questions)
                {
                    Item? itemReward = qd.ItemReward != null
                        ? new Item(qd.ItemReward.Name, qd.ItemReward.Description)
                        : null;
                    npc.Questions.Add(new Question(qd.Text, qd.Answer, qd.Reward, itemReward));
                }
                room.Npcs.Add(npc);
            }

            _rooms[rd.Key] = room;
        }

        // Fáze 2: propojit východy (až všechny místnosti existují)
        foreach (var rd in dto.Rooms)
        {
            var room = _rooms[rd.Key];
            foreach (var exit in rd.Exits)
            {
                if (_rooms.TryGetValue(exit.Value, out var target))
                    room.AddExit(exit.Key, target);
                else
                    Logger.Log($"[Svět] Chybí místnost '{exit.Value}' pro východ '{exit.Key}' z '{rd.Key}'");
            }
        }

        // Shop
        foreach (var si in dto.Shop.Items)
            Shop.Items.Add(new ShopItem(si.Name, si.Description, si.Price));

        if (!_rooms.TryGetValue(dto.StartRoom, out var startRoom))
            throw new Exception($"Počáteční místnost '{dto.StartRoom}' nebyla nalezena v JSON.");

        StartRoom = startRoom;
    }

    // =========================================================
    // Výchozí svět (záloha pokud world.json chybí)
    // =========================================================
    private void BuildWorld()
    {
        var hrad = new Room("hrad", "Hrad",
            "Mohutné kamenné hradby se tyčí do nebe. Ve velkém sále\n" +
            "hoří krb a na trůně sedí Král. Princezna se prochází\n" +
            "po nádvoří. Uprostřed nádvoří leží zakletá Tulipánka.\n" +
            "POZOR: vstup vyžaduje 3 klíče!");
        hrad.RequiredKeys = 3;

        var les = new Room("les", "Les",
            "Hustý jehličnatý les. Vůně pryskyřice a mechem pokryté\n" +
            "kameny. Mezi stromy se mihne Myslivec s kuší na rameni.");

        var vesnice = new Room("vesnice", "Vesnice",
            "Malebná vesnice se šindelovými střechami. Slepice pobíhají\n" +
            "po návsi. Vesničan opravuje plot. Tady je OBCHOD!");

        var jezero = new Room("jezero", "U jezera",
            "Klidné modré jezero s průzračnou vodou. Na břehu sedí\n" +
            "Žába a pozoruje kruhy na hladině.");

        var farma = new Room("farma", "Farma",
            "Červená stodola uprostřed zlatých polí. Farmář opravuje\n" +
            "plot a hvízdá si. Pes líně leží ve stínu stodoly.");

        var reky = new Room("reky", "U řeky",
            "Klidná řeka se tu mírně vine krajinou. Ryby se třepytí\n" +
            "v čisté vodě.");

        var hory = new Room("hory", "Hory",
            "Skalnaté vrcholky pokryté věčným sněhem. Ostrý vítr\n" +
            "řeže do obličeje. Horolezec si kontroluje lano.");

        var pole = new Room("pole", "Pole",
            "Rozlehlé zelené pole se vlní ve větru jako moře.\n" +
            "Malá Myška pobíhá mezi stébly trávy.");

        var lesJih = new Room("lesjih", "Les na jihu",
            "Světlejší les než na severu. Sluneční paprsky pronikají\n" +
            "korunami stromů. Srna se klidně pase.");

        // Propojení místností
        hrad.AddExit("vychod", les); les.AddExit("zapad", hrad);
        les.AddExit("vychod", vesnice); vesnice.AddExit("zapad", les);
        jezero.AddExit("vychod", farma); farma.AddExit("zapad", jezero);
        farma.AddExit("vychod", reky); reky.AddExit("zapad", farma);
        hory.AddExit("vychod", pole); pole.AddExit("zapad", hory);
        pole.AddExit("vychod", lesJih); lesJih.AddExit("zapad", pole);
        hrad.AddExit("jih", jezero); jezero.AddExit("sever", hrad);
        jezero.AddExit("jih", hory); hory.AddExit("sever", jezero);
        les.AddExit("jih", farma); farma.AddExit("sever", les);
        farma.AddExit("jih", pole); pole.AddExit("sever", farma);
        vesnice.AddExit("jih", reky); reky.AddExit("sever", vesnice);
        reky.AddExit("jih", lesJih); lesJih.AddExit("sever", reky);

        // NPC
        var princezna = new Npc("Princezna",
            "Ach, konečně někdo nový! Zvládni můj kvíz a získáš\n  zlaté jako odměnu! Příkaz: kviz Princezna");
        princezna.Questions.Add(new Question("Kolik je 7 × 8?", "56", 5));
        princezna.Questions.Add(new Question("Kolik je 15 + 27?", "42", 5));
        princezna.Questions.Add(new Question("Kolik je 100 - 63?", "37", 5));
        hrad.Npcs.Add(princezna);

        var kral = new Npc("Král",
            "Vítej, poutníče! Zodpověz moje otázky a získáš\n  zlaté jako odměnu! Příkaz: kviz Král");
        kral.Questions.Add(new Question("Jak se jmenuje hlavní město České republiky?", "Praha", 8));
        kral.Questions.Add(new Question("Kolik planet je ve sluneční soustavě?", "8", 6));
        kral.Questions.Add(new Question("Který je největší oceán na Zemi?", "Tichý", 7));
        hrad.Npcs.Add(kral);

        hrad.Npcs.Add(new Npc("Tulipánka",
            "...jsi to opravdu ty? Přišel jsi mě zachránit!\n  Děkuji ti, odvážný dobrodruhu! Nyní jsem svobodná! <3"));

        var myslivec = new Npc("Myslivec",
            "Tiše! Plašíš zvěř... Ale jestli zodpovíš moje otázky\n  o přírodě, dám ti železný klíč! Příkaz: kviz Myslivec");
        myslivec.Questions.Add(new Question("Kolik noh má jelen?", "4", 3));
        myslivec.Questions.Add(new Question("Jak se jmenuje mladá liška?", "lišče", 4));
        myslivec.Questions.Add(new Question("Který pták umí napodobit hlas člověka?", "papoušek", 5,
            new Item("klíč železný", "Železný klíč získaný od Myslivce. Jeden ze tří klíčů do hradu.")));
        les.Npcs.Add(myslivec);

        var vesnicán = new Npc("Vesničan",
            "Nazdar! Určitě vyhraješ v mém kvízu! Příkaz: kviz Vesničan");
        vesnicán.Questions.Add(new Question("Kolik dní má rok?", "365", 4));
        vesnicán.Questions.Add(new Question("Kolik je 12 × 12?", "144", 5));
        vesnicán.Questions.Add(new Question("Jak se jmenuje naše planeta?", "Země", 3));
        vesnice.Npcs.Add(vesnicán);

        var zaba = new Npc("Žába",
            "*kvak* Víš toho víc než já? Zkus kvíz! Příkaz: kviz Žába");
        zaba.Questions.Add(new Question("Kolik noh má pavouk?", "8", 4));
        zaba.Questions.Add(new Question("Jak se jmenuje největší živočich na Zemi?", "velryba", 6));
        zaba.Questions.Add(new Question("Kolik vajec snese slepice přibližně za rok? (číslo)", "300", 5));
        jezero.Npcs.Add(zaba);

        farma.Npcs.Add(new Npc("Farmář",
            "Hej, pomůžeš mi? Potřebuji odvézt seno do stodoly.\n  Za odměnu ti dám čerstvé jablko ze zahrady!"));
        farma.Npcs.Add(new Npc("Pes",
            "*vrtí ocasem* Haf! Haf haf! *přivřele olizuje ruku*"));

        var horolezec = new Npc("Horolezec",
            "Tohle jsou nejkrásnější hory! Zvládni můj kvíz\n  a získáš stříbrný klíč do hradu! Příkaz: kviz Horolezec");
        horolezec.Questions.Add(new Question("Jak se jmenuje nejvyšší hora světa?", "Everest", 8));
        horolezec.Questions.Add(new Question("Ve které zemi leží Matterhorn?", "Švýcarsko", 6));
        horolezec.Questions.Add(new Question("Kolik metrů má 1 kilometr?", "1000", 4,
            new Item("klíč stříbrný", "Stříbrný klíč získaný od Horolezce. Jeden ze tří klíčů do hradu.")));
        hory.Npcs.Add(horolezec);

        pole.Npcs.Add(new Npc("Myška",
            "*pip pip* Dávej pozor kde šlapeš! Tady mám schovány\n  zásoby na zimu! *pip*"));
        lesJih.Npcs.Add(new Npc("Srna",
            "*zvedne hlavu a pozoruje tě klidnýma očima*\n  ...ticho... *vrátí se ke spásání trávy*"));

        // Předměty
        hrad.Items.Add(new Item("zlatý klíč", "Lesklý zlatý klíč s královskou korunou."));
        farma.Items.Add(new Item("jablko", "Červené, šťavnaté jablko rovnou ze zahrady. Mňam!"));
        hory.Items.Add(new Item("lano", "Pevné horolezecké lano."));
        les.Items.Add(new Item("lesní kvítí", "Krásná kytice lesních květin. Princezna by se určitě potěšila!"));
        pole.Items.Add(new Item("zrnko pšenice", "Velké zlaté zrnko pšenice."));
        lesJih.Items.Add(new Item("větvička", "Rovná, pevná větvička ze starého dubu."));
        reky.Items.Add(new Item("oblázek", "Hladký oblázek vyhlazený řekou."));

        // Shop
        Shop.Items.Add(new ShopItem("lektvar zdraví", "Obnoví tvoje zdraví a dodá náladu.", 5));
        Shop.Items.Add(new ShopItem("pochodeň", "Světlo do tmy. Hoří dlouho.", 3));
        Shop.Items.Add(new ShopItem("chléb", "Čerstvý chléb z pečení. Sytá věc.", 2));
        Shop.Items.Add(new ShopItem("klíč bronzový",
            "Jeden ze tří klíčů potřebných pro vstup do hradu. Další dva získáš od NPC!", 10));

        _rooms["hrad"] = hrad;
        _rooms["les"] = les;
        _rooms["vesnice"] = vesnice;
        _rooms["jezero"] = jezero;
        _rooms["farma"] = farma;
        _rooms["reky"] = reky;
        _rooms["hory"] = hory;
        _rooms["pole"] = pole;
        _rooms["lesjih"] = lesJih;
    }

    // =========================================================
    // Správa hráčů
    // =========================================================
    public void AddPlayer(Player player)
    {
        lock (_playersLock) _players[player.Name] = player;
        Logger.Log($"[Svět] Hráč '{player.Name}' vstoupil do hry. Online: {_players.Count}");
    }

    public void RemovePlayer(string name)
    {
        lock (_playersLock) _players.Remove(name);
        Logger.Log($"[Svět] Hráč '{name}' opustil hru. Online: {_players.Count}");
    }

    public List<string> GetPlayersInRoom(Room room, string excludeName)
    {
        lock (_playersLock)
            return _players.Values
                .Where(p => p.CurrentRoom == room && p.Name != excludeName)
                .Select(p => p.Name)
                .ToList();
    }

    public Room? GetRoomByKey(string key)
    {
        _rooms.TryGetValue(key, out var room);
        return room;
    }
}
