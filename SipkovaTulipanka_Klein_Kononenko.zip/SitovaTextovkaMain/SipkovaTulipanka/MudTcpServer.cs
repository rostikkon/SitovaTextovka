// ============================================================
// MudTcpServer.cs – TCP server, který přijímá hráče
// ============================================================

namespace MudServer;

using System.Net;
using System.Net.Sockets;

public class MudTcpServer
{
    private readonly int _port;
    private readonly GameWorld _world;
    private readonly AccountManager _accounts;

    public MudTcpServer(int port, GameWorld world, AccountManager accounts)
    {
        _port = port;
        _world = world;
        _accounts = accounts;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        var listener = new TcpListener(IPAddress.Any, _port);
        listener.Start();

        Logger.Log($"[Server] Naslouchám na portu {_port}. Čekám na hráče...");

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken);

                string clientIp = client.Client.RemoteEndPoint?.ToString() ?? "neznámý";
                Logger.Log($"[Server] Nové spojení od: {clientIp}");

                Player player = new Player(client, _world, _accounts);

                _ = player.HandleAsync().ContinueWith(t =>
                {
                    if (t.IsFaulted)
                        Logger.Log($"[Chyba] Neočekávaná chyba hráče: {t.Exception?.InnerException?.Message}");
                }, TaskScheduler.Default);
            }
        }
        catch (OperationCanceledException)
        {
            // Normální ukončení přes Ctrl+C
        }
        finally
        {
            listener.Stop();
            Logger.Log("[Server] Listener zastaven.");
        }
    }
}
