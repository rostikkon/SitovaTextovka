using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class MultiTest
{
    static string Norm(string s)
    {
        var map = new[] {
            ("á","a"),("č","c"),("ě","e"),("í","i"),("ř","r"),("š","s"),
            ("ú","u"),("ů","u"),("ý","y"),("ž","z"),("Á","A"),("Č","C"),
            ("Ě","E"),("Í","I"),("Ř","R"),("Š","S"),("Ú","U"),("Ů","U"),
            ("Ý","Y"),("Ž","Z")
        };
        foreach (var (f, t) in map) s = s.Replace(f, t);
        return s.ToLower();
    }

    static async Task<string> ReadAll(StreamReader r, int ms = 1500)
    {
        var sb = new StringBuilder();
        var cts = new CancellationTokenSource(ms);
        try
        {
            while (true)
            {
                string? l = await r.ReadLineAsync(cts.Token);
                if (l == null) break;
                sb.AppendLine(l);
            }
        }
        catch { }
        return sb.ToString();
    }

    static async Task<string> Send(StreamWriter w, StreamReader r, string cmd, int wait = 1000)
    {
        await w.WriteLineAsync(cmd);
        await Task.Delay(wait);
        return await ReadAll(r, 700);
    }

    static async Task<string> RegisterAndPlay(string host, int port, string user, string pwd, int delayMs)
    {
        await Task.Delay(delayMs);
        using var c = new TcpClient();
        await c.ConnectAsync(host, port);
        var s = c.GetStream();
        var r = new StreamReader(s, Encoding.UTF8, leaveOpen: true);
        var w = new StreamWriter(s, Encoding.UTF8, leaveOpen: true) { AutoFlush = true, NewLine = "\r\n" };

        await ReadAll(r, 2200);
        await w.WriteLineAsync(user);
        await Task.Delay(600);
        await ReadAll(r, 1000);
        await w.WriteLineAsync("ano");
        await Task.Delay(500);
        await ReadAll(r, 800);
        await w.WriteLineAsync(pwd);
        await Task.Delay(500);
        await ReadAll(r, 800);
        await w.WriteLineAsync(pwd);
        await Task.Delay(1200);
        await ReadAll(r, 1500);

        await Task.Delay(1200);

        string look = await Send(w, r, "prozkoumej", 1500);
        await w.WriteLineAsync("konec");
        await Task.Delay(600);
        return look;
    }

    static async Task Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine("=== TEST MULTI-PLAYER: 2 hráči současně na Farmě ===\n");

        string ts = DateTime.Now.ToString("HHmmss");
        string u1 = $"mp1_{ts}";
        string u2 = $"mp2_{ts}";
        const string pwd = "Test1234";

        Console.WriteLine($"Hráč 1: {u1}");
        Console.WriteLine($"Hráč 2: {u2}\n");

        var t1 = RegisterAndPlay("127.0.0.1", 4000, u1, pwd, 0);
        var t2 = RegisterAndPlay("127.0.0.1", 4000, u2, pwd, 700);

        string[] results = await Task.WhenAll(t1, t2);
        string p1Look = results[0];
        string p2Look = results[1];

        Console.WriteLine("--- Pohled Hráče 1 (prozkoumej) ---");
        string p1Preview = p1Look.Trim();
        if (p1Preview.Length > 300) p1Preview = p1Preview[..300] + "...";
        Console.WriteLine(p1Preview);

        Console.WriteLine("\n--- Pohled Hráče 2 (prozkoumej) ---");
        string p2Preview = p2Look.Trim();
        if (p2Preview.Length > 300) p2Preview = p2Preview[..300] + "...";
        Console.WriteLine(p2Preview);
        Console.WriteLine();

        int pass = 0, fail = 0;
        void Check(string name, bool ok, string info = "")
        {
            if (ok) { pass++; Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine($"  [PASS] {name}"); }
            else { fail++; Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"  [FAIL] {name}" + (string.IsNullOrEmpty(info) ? "" : $": {info}")); }
            Console.ResetColor();
        }

        Check("MP-01 Hráč 1 je na Farmě (startovní místnost)",  Norm(p1Look).Contains("farma"));
        Check("MP-02 Hráč 2 je na Farmě (startovní místnost)",  Norm(p2Look).Contains("farma"));
        Check("MP-03 Hráč 1 vidí Hráče 2 v místnosti",          Norm(p1Look).Contains(Norm(u2)));
        Check("MP-04 Hráč 2 vidí Hráče 1 v místnosti",          Norm(p2Look).Contains(Norm(u1)));
        Check("MP-05 Zobrazeno označení '(hráč)'",               Norm(p1Look).Contains("(hrac)") || Norm(p2Look).Contains("(hrac)"));
        Check("MP-06 Server přijal oba hráče souč. (non-empty)", p1Look.Length > 10 && p2Look.Length > 10);

        Console.WriteLine($"\nVÝSLEDEK MULTI-PLAYER: {pass} PASS / {fail} FAIL");
    }
}
