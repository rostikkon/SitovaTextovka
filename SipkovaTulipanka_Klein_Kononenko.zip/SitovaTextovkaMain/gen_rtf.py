#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate VzorTestu.rtf with complete test cases for Sipkova Tulipanka MUD."""

import io

def rtf_str(text):
    """Encode a string to RTF-safe bytes using cp1250, escaping special RTF chars."""
    out = []
    for ch in text:
        if ch == '\\':
            out.append('\\\\')
        elif ch == '{':
            out.append('\\{')
        elif ch == '}':
            out.append('\\}')
        else:
            try:
                b = ch.encode('cp1250')
                if len(b) == 1 and b[0] < 128:
                    out.append(ch)
                else:
                    for byte in b:
                        out.append(f"\\'{byte:02x}")
            except (UnicodeEncodeError, ValueError):
                # fallback: Unicode escape
                out.append(f"\\u{ord(ch)}?")
    return ''.join(out)

def r(text):
    return rtf_str(text)

# ---- RTF structural helpers ----
BORDER_FULL = (
    r"\clbrdrt\brdrs\brdrw20\brdrcf1"
    r"\clbrdrl\brdrs\brdrw20\brdrcf1"
    r"\clbrdrb\brdrs\brdrw20\brdrcf1"
    r"\clbrdrr\brdrs\brdrw20\brdrcf1"
)
BORDER_NOTOP = (
    r"\clbrdrt\brdrtbl"
    r"\clbrdrl\brdrs\brdrw20\brdrcf1"
    r"\clbrdrb\brdrs\brdrw20\brdrcf1"
    r"\clbrdrr\brdrs\brdrw20\brdrcf1"
)
BORDER_FULL_NORIGHT = (
    r"\clbrdrt\brdrs\brdrw20\brdrcf1"
    r"\clbrdrl\brdrs\brdrw20\brdrcf1"
    r"\clbrdrb\brdrs\brdrw20\brdrcf1"
    r"\clbrdrr\brdrtbl"
)

# Step table borders
SH = (  # step header cell
    r"\clvertalc\clbrdrt\brdrs\brdrw10\brdrcf1"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrtbl"
    r"\clshdng2000\cltxlrtb"
)
SH_LAST = (  # step header last cell
    r"\clvertalc\clbrdrt\brdrs\brdrw10\brdrcf1"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrs\brdrw10\brdrcf1"
    r"\clshdng2000\cltxlrtb"
)
SD = (  # step data cell
    r"\clvertalc\clbrdrt\brdrtbl"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrtbl"
    r"\cltxlrtb"
)
SD_LAST = (  # step data last cell
    r"\clvertalc\clbrdrt\brdrtbl"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrs\brdrw10\brdrcf1"
    r"\cltxlrtb"
)

# Column widths (cumulative twips, landscape)
W1=660; W2=3765; W3=7035; W4=10020; W5=13070

def step_header_row():
    s = f"\n\\trowd\\trleft0\\trftsWidth1"
    s += f"{SH}\\cellx{W1}"
    s += f"{SH}\\cellx{W2}"
    s += f"{SH}\\cellx{W3}"
    s += f"{SH}\\cellx{W4}"
    s += f"{SH_LAST}\\cellx{W5}"
    s += f"\n\\pard\\plain\\intbl\\qc{{\\b {r('Step')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Test Steps')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Test Data')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Expected Result')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Notes')}}}\\cell"
    s += f"\n\\row"
    return s

def step_row(n, step, data, expected, notes=""):
    s = f"\n\\trowd\\trleft0\\trftsWidth1"
    s += f"{SD}\\cellx{W1}"
    s += f"{SD}\\cellx{W2}"
    s += f"{SD}\\cellx{W3}"
    s += f"{SD}\\cellx{W4}"
    s += f"{SD_LAST}\\cellx{W5}"
    s += f"\n\\pard\\plain\\intbl\\qc {n}\\cell"
    s += f"\\pard\\plain\\intbl\\ql {r(step)}\\cell"
    s += f"\\pard\\plain\\intbl\\ql {r(data)}\\cell"
    s += f"\\pard\\plain\\intbl\\ql {r(expected)}\\cell"
    s += f"\\pard\\plain\\intbl\\ql {r(notes)}\\cell"
    s += f"\n\\row"
    return s

def tc(tc_id, name, desc, pre, deps, steps):
    """Generate one complete test case block."""
    designer = "Student1 Student2"
    s = ""
    # Title row
    s += f"\n\\trowd\\trleft30\\trftsWidth1\\clbrdrt\\brdrtbl\\clbrdrl\\brdrtbl\\clbrdrb\\brdrtbl\\clbrdrr\\brdrtbl\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\qc{{\\b\\fs40 SPSE Jecna Test Case}}\\cell\\row"
    # ID + Designer
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_FULL_NORIGHT}\\cltxlrtb\\cellx6379{BORDER_FULL}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Test Case ID: ')}}}{r(tc_id)}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Test Designed by: ')}}}{r(designer)}\\cell\\row"
    # Test Name
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_NOTOP}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Test Name: ')}}}{r(name)}\\cell\\row"
    # Brief Description
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_NOTOP}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Brief description: ')}}}{r(desc)}\\cell\\row"
    # Pre-conditions
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_NOTOP}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Pre-conditions: ')}}}{r(pre)}\\cell\\row"
    # Dependencies
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_NOTOP}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Dependencies and Requirements: ')}}}{r(deps)}\\cell\\row"
    # Spacer
    s += f"\n\\pard\\plain\\ql\\sb100\\sa100\\par"
    # Steps table
    s += step_header_row()
    for (n, step, data, expected, notes) in steps:
        s += step_row(n, step, data, expected, notes)
    # Page break
    s += "\n\\page"
    return s


# ============================================================
# COMMON SETUP TEXT
# ============================================================
SERVER = "127.0.0.1, port 4000"
DEPS_COMMON = "Server Šípková Tulipánka běžící na 127.0.0.1:4000. PuTTY nebo jiný TCP klient. Účet test_player/Test123 musí existovat."
DEPS_SAVED = "Server běžící na 127.0.0.1:4000. Účet saved_player/Save123 musí mít uložen stav: místnost Vesnice, 25 zlatých, klíč bronzový + pochodeň."

# ============================================================
# ALL TEST CASES
# ============================================================
cases = []

# ---- ACCOUNTS PAGE ----
# (written separately below as a plain page)

# ====== MVP ======

cases.append(tc(
    "MVP-01",
    "Spuštění serveru a naslouchání na portu 4000",
    "Ověřit, že server se úspěšně spustí a naslouchá na TCP portu 4000.",
    ".NET 8 SDK nainstalován. Port 4000 volný (nepoužívá jej jiná aplikace). Projekt SipkovaTulipanka zkompilován (dotnet build).",
    "Windows 10/11 s .NET 8 runtime. PowerShell nebo příkazový řádek. Nástroj netstat.",
    [
        (1, "Otevřít PowerShell a přejít do složky SipkovaTulipanka.", "-", "PowerShell zobrazí cestu projektu.", ""),
        (2, "Spustit příkaz: dotnet run", "dotnet run", "Konzole vypíše: 'Server nasloucha na portu 4000.' Poté server čeká na připojení.", ""),
        (3, "Otevřít druhý PowerShell a spustit: netstat -an | findstr 4000", "Port: 4000", "Výstup obsahuje řádek s '0.0.0.0:4000' a stavem 'LISTENING'.", ""),
        (4, "Stisknout Ctrl+C v okně serveru.", "Ctrl+C", "Server vypíše 'Server ukoncen.' a ukončí se bez chyby.", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "MVP-02",
    "Přihlášení – neexistující hráč (chybový stav)",
    "Ověřit, že server správně reaguje na jméno neexistujícího hráče: nabídne registraci a po odmítnutí odpojí.",
    "Server běžící na 127.0.0.1:4000. Účet 'ghost_player_999' NESMÍ existovat v players.json.",
    "PuTTY (Connection type: Raw, Host: 127.0.0.1, Port: 4000). Nebo jiný TCP klient.",
    [
        (1, "Spustit PuTTY: Host=127.0.0.1, Port=4000, Connection type=Raw. Kliknout Open.", SERVER, "Terminál zobrazí úvodní banner: '   Vitej v MUD svete! Sipkova Tulipanka  ' a výzvu 'Uzivatelske jmeno: '.", ""),
        (2, "Zadat jméno neexistujícího hráče a stisknout Enter.", "Jméno: ghost_player_999", "Server odpoví: \"Ucet 'ghost_player_999' nenalezen.\" a zobrazí výzvu 'Zaregistrovat novy ucet? (ano/ne): '.", ""),
        (3, "Zadat odpověď 'ne' a stisknout Enter.", "Odpověď: ne", "Server odpoví 'Nashledanou!' a ukončí připojení. PuTTY oznámí 'Connection closed by remote host'.", ""),
        (4, "-", "-", "-", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "MVP-03",
    "Přihlášení – špatné heslo 3× → zablokování (chybový stav)",
    "Ověřit, že po třech chybných pokusech o heslo server odpojí klienta.",
    "Server běžící na 127.0.0.1:4000. Účet 'test_player' musí existovat s heslem 'Test123'.",
    "PuTTY nebo jiný TCP klient. Znalost špatného hesla: 'WrongPass'.",
    [
        (1, "Připojit PuTTY: 127.0.0.1:4000. Po zobrazení banneru zadat jméno a stisknout Enter.", "Jméno: test_player", "Server zobrazí výzvu 'Heslo: '.", ""),
        (2, "Zadat špatné heslo a stisknout Enter.", "Heslo: WrongPass", "Server odpoví: 'Spatne heslo. Zbyvaji 2 pokusy.' a znovu zobrazí 'Heslo: '.", ""),
        (3, "Zadat špatné heslo podruhé.", "Heslo: WrongPass", "Server odpoví: 'Spatne heslo. Zbyvaji 1 pokusy.' a znovu zobrazí 'Heslo: '.", ""),
        (4, "Zadat špatné heslo potřetí.", "Heslo: WrongPass", "Server odpoví: 'Prilis mnoho spatnych pokusu. Odpojuji.' a ukončí spojení.", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "MVP-04",
    "Přihlášení – platné přihlášení existujícího hráče",
    "Ověřit úspěšné přihlášení hráče test_player se správným heslem a zobrazení startovní místnosti.",
    "Server běžící na 127.0.0.1:4000. Účet test_player/Test123 existuje. Hráč není přihlášen z jiného spojení.",
    "PuTTY nebo jiný TCP klient.",
    [
        (1, "Připojit PuTTY: 127.0.0.1:4000. Zobrazí se banner a výzva 'Uzivatelske jmeno: '.", SERVER, "Úvodní banner obsahuje 'Vitej v MUD svete! Sipkova Tulipanka'.", ""),
        (2, "Zadat jméno a stisknout Enter.", "Jméno: test_player", "Server zobrazí výzvu 'Heslo: '.", ""),
        (3, "Zadat správné heslo a stisknout Enter.", "Heslo: Test123", "Server zobrazí: 'Vitej, test_player! Mas 0 zlatych.' a popis místnosti.", ""),
        (4, "Sledovat popis místnosti.", "-", "Výstup obsahuje '+== FARMA ==+', popis Farmy, sekci '[ Východy ]' se směry, '[ Předměty ]' a '[ Postavy ]'.", ""),
        (5, "Zadat příkaz: konec", "konec", "Server odpoví 'Nashledanou, dobrodrhu! Stav ulozin.' a odpojí.", ""),
    ]
))

cases.append(tc(
    "MVP-05",
    "Registrace nového hráče",
    "Ověřit, že nový hráč může vytvořit účet a přihlásit se do hry.",
    "Server běžící na 127.0.0.1:4000. Účet 'new_player_001' NESMÍ existovat v players.json před testem.",
    "PuTTY nebo jiný TCP klient.",
    [
        (1, "Připojit PuTTY: 127.0.0.1:4000. Zadat neexistující jméno.", "Jméno: new_player_001", "Server odpoví: \"Ucet 'new_player_001' nenalezen.\" a zobrazí výzvu 'Zaregistrovat novy ucet? (ano/ne): '.", ""),
        (2, "Zadat 'ano'.", "Odpověď: ano", "Server zobrazí výzvu 'Nove heslo (min. 4 znaky): '.", ""),
        (3, "Zadat nové heslo.", "Heslo: New123", "Server zobrazí výzvu 'Potvrdte heslo: '.", ""),
        (4, "Zadat stejné heslo pro potvrzení.", "Potvrzení: New123", "Server odpoví: \"Ucet 'new_player_001' uspesne vytvoren!\" a přihlásí hráče do Farmy.", ""),
        (5, "Sledovat výstup po registraci.", "-", "Zobrazí se uvítání 'Vitej, new_player_001!' a popis startovní místnosti +== FARMA ==+.", ""),
    ]
))

cases.append(tc(
    "MVP-06",
    "Příkaz prozkoumej – zobrazení místnosti",
    "Ověřit, že příkaz prozkoumej zobrazí kompletní informace o aktuální místnosti (popis, východy, předměty, postavy).",
    "Server běžící na 127.0.0.1:4000. Přihlášen jako test_player ve startovní místnosti Farma.",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123.", "test_player / Test123", "Hráč přihlášen, zobrazena Farma.", ""),
        (2, "Zadat příkaz: prozkoumej", "prozkoumej", "Výstup obsahuje '+== FARMA ==+' (název místnosti velkými písmeny).", ""),
        (3, "Sledovat sekci východů.", "-", "Výstup obsahuje '[ Východy ]' a seznam dostupných směrů: zapad, vychod, sever, jih.", ""),
        (4, "Sledovat sekci předmětů.", "-", "Výstup obsahuje '[ Předměty ]' a položku '* jablko'.", ""),
        (5, "Sledovat sekci postav.", "-", "Výstup obsahuje '[ Postavy ]' a 'Farmář (NPC)', 'Pes (NPC)'.", ""),
    ]
))

cases.append(tc(
    "MVP-07",
    "Pohyb jdi – platný směr",
    "Ověřit, že příkaz 'jdi sever' přesune hráče z Farmy do Lesa.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player přihlášen na Farmě.",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Ověřit přítomnost na Farmě.", "test_player / Test123", "+== FARMA ==+ zobrazen.", ""),
        (2, "Zadat příkaz: jdi sever", "jdi sever", "Server odpoví 'Jdes sever...' a zobrazí popis nové místnosti.", ""),
        (3, "Sledovat popis nové místnosti.", "-", "Výstup obsahuje '+== LES ==+' a popis Lesa.", ""),
        (4, "Sledovat sekci východů v Lese.", "-", "Sekce [ Východy ] obsahuje směry: zapad, vychod, jih.", ""),
        (5, "Zadat: jdi jih pro návrat na Farmu.", "jdi jih", "Server zobrazí '+== FARMA ==+'. Pohyb zpět funguje.", ""),
    ]
))

cases.append(tc(
    "MVP-08",
    "Pohyb jdi – neplatný směr (chybový stav)",
    "Ověřit, že při zadání neexistujícího směru server zobrazí srozumitelnou chybovou hlášku a neukončí session.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player v Lese (Les nemá východ 'sever').",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Přesunout se do Lesa: jdi sever", "test_player / Test123", "Hráč v Lese (+== LES ==+).", ""),
        (2, "Zadat neexistující směr: jdi sever", "jdi sever", "Server odpoví: \"Smer 'sever' odsud nevede. Dostupne: zapad, vychod, jih\"", "Les nemá sever"),
        (3, "Ověřit, že hráč zůstává v Lese.", "prozkoumej", "Zobrazí se '+== LES ==+' – hráč se nepřesunul.", ""),
        (4, "Zadat příkaz bez směru: jdi", "jdi", "Server odpoví: 'Kam chces jit? Priklad: jdi sever'", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "MVP-09",
    "Příkaz vezmi – zvednutí předmětu",
    "Ověřit, že příkaz 'vezmi jablko' vezme předmět z místnosti do inventáře.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player přihlášen na Farmě. Jablko musí být v místnosti (nebylo dříve vzato).",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Ověřit předměty na Farmě: prozkoumej", "test_player / Test123", "[ Předměty ] obsahuje '* jablko'.", ""),
        (2, "Zadat: vezmi jablko", "vezmi jablko", "Server odpoví: 'Vzal/a jsi: jablko'", ""),
        (3, "Ověřit inventář: inventar", "inventar", "Inventář zobrazí '[ Inventar ] (1/10) | Zlato: 0' a řádek '* jablko - ...'.", ""),
        (4, "Ověřit, že jablko zmizelo z místnosti: prozkoumej", "prozkoumej", "[ Předměty ] zobrazí 'Nic tu nelezi.' – jablko není v místnosti.", ""),
        (5, "Zkusit vzít neexistující předmět: vezmi drak", "vezmi drak", "Server odpoví: \"Predmet 'drak' tu nevidim.\"", "Chybový stav"),
    ]
))

cases.append(tc(
    "MVP-10",
    "Příkaz poloz – položení předmětu",
    "Ověřit, že příkaz 'poloz jablko' odloží předmět z inventáře do místnosti.",
    "Hráč test_player má v inventáři jablko (viz MVP-09). Server běžící na 127.0.0.1:4000.",
    DEPS_COMMON,
    [
        (1, "Pokračovat po MVP-09. Ověřit, že inventář obsahuje jablko: inventar", "-", "'[ Inventar ] (1/10)' a '* jablko' zobrazeny.", ""),
        (2, "Zadat: poloz jablko", "poloz jablko", "Server odpoví: 'Polozil/a jsi: jablko'", ""),
        (3, "Ověřit inventář: inventar", "inventar", "'[ Inventar ] (0/10)' a 'Nic u sebe nemas.' – jablko v inventáři není.", ""),
        (4, "Ověřit předměty v místnosti: prozkoumej", "prozkoumej", "[ Předměty ] zobrazí '* jablko' – jablko je zpět v místnosti.", ""),
        (5, "Zkusit položit předmět, který hráč nemá: poloz mec", "poloz mec", "Server odpoví: \"'mec' nemas u sebe.\"", "Chybový stav"),
    ]
))

cases.append(tc(
    "MVP-11",
    "Příkaz inventar – zobrazení inventáře",
    "Ověřit, že příkaz inventar správně zobrazí obsah inventáře a množství zlata.",
    "Server běžící na 127.0.0.1:4000. Pro prázdný inventář: test_player (0 předmětů, 0 zlata). Pro plný: saved_player (2 předměty, 25 zlata).",
    DEPS_COMMON + " " + DEPS_SAVED,
    [
        (1, "Přihlásit se jako test_player/Test123. Zadat: inventar", "test_player / Test123", "Zobrazí se: '[ Inventar ] (0/10) | Zlato: 0' a 'Nic u sebe nemas.'", "Prázdný inventář"),
        (2, "Odpojit se (konec). Přihlásit se jako saved_player/Save123.", "saved_player / Save123", "Hráč přihlášen ve Vesnici.", ""),
        (3, "Zadat: inventar", "inventar", "Zobrazí se: '[ Inventar ] (2/10) | Zlato: 25'", ""),
        (4, "Sledovat seznam předmětů.", "-", "Výstup obsahuje řádek '* klíč bronzový - ...' a '* pochodeň - ...'", ""),
        (5, "Zadat: penize", "penize", "Server odpoví: 'Mas 25 zlatych.'", "Alternativní příkaz"),
    ]
))

cases.append(tc(
    "MVP-12",
    "Příkaz mluv – rozhovor s NPC",
    "Ověřit, že příkaz mluv spustí dialog s NPC v aktuální místnosti a chybový stav pro neexistující postavu.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player na Farmě (NPC: Farmář, Pes).",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Zadat: mluv Farmar", "mluv Farmar", "Server zobrazí dialog Farmáře začínající: 'Farmář říká: \"Hej, pomůžeš mi?...'", ""),
        (2, "Zadat příkaz pro NPC bez kvízu: mluv Pes", "mluv Pes", "Server zobrazí dialog Psa začínající: 'Pes říká: \"*vrtí ocasem*...'", ""),
        (3, "Zadat příkaz pro neexistující postavu: mluv drak", "mluv drak", "Server odpoví: \"'drak' tu neni.\"", "Chybový stav"),
        (4, "Přesunout se do Lesa (jdi sever). Zadat: mluv Myslivec", "mluv Myslivec", "Dialog Myslivce zobrazen. Obsahuje tip: \"(Tip: prikaz 'kviz Myslivec' pro kviz s odmenou!)\"", "NPC s kvízem"),
        (5, "Zadat bez jména: mluv", "mluv", "Server odpoví: 'S kym chces mluvit? Priklad: mluv Farmar'", "Chybový stav"),
    ]
))

cases.append(tc(
    "MVP-13",
    "Více hráčů současně – viditelnost v místnosti",
    "Ověřit, že dvě současně přihlášená spojení vidí navzájem ve stejné místnosti označení (hráč).",
    "Server běžící na 127.0.0.1:4000. Dva dostupné TCP klienty (dvě okna PuTTY). Účty: test_player/Test123, saved_player/Save123.",
    "Dva samostatné TCP klienty (dvě okna PuTTY nebo dvě instance MudClient).",
    [
        (1, "Otevřít PuTTY #1. Přihlásit se jako test_player/Test123. Ověřit přítomnost na Farmě.", "test_player / Test123", "test_player přihlášen na Farmě.", ""),
        (2, "Otevřít PuTTY #2. Přihlásit se jako saved_player/Save123. Přesunout se na Farmu: jdi sever NENADO, saved_player je ve Vesnici. Tedy: jdi zapad, jdi jih.", "saved_player / Save123, trasa: Vesnice→Les→Farma (jdi zapad, jdi jih)", "saved_player přihlášen a přesunut na Farmu.", ""),
        (3, "V PuTTY #1 zadat: prozkoumej", "prozkoumej", "Výstup sekce [ Postavy ] obsahuje 'saved_player (hráč)'.", ""),
        (4, "V PuTTY #2 zadat: prozkoumej", "prozkoumej", "Výstup sekce [ Postavy ] obsahuje 'test_player (hráč)'.", ""),
        (5, "V PuTTY #1 odpojit (konec). V PuTTY #2 zadat: prozkoumej.", "konec, prozkoumej", "Po odpojení test_player se jméno test_player nezobrazí v místnosti hráče 2.", ""),
    ]
))

cases.append(tc(
    "MVP-14",
    "Příkaz pomoc – seznam příkazů",
    "Ověřit, že příkaz pomoc zobrazí seznam všech dostupných příkazů.",
    "Server běžící na 127.0.0.1:4000. Přihlášen jako test_player.",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Zadat: pomoc", "pomoc", "Server zobrazí hlavičku '+=========================================+'", ""),
        (2, "Sledovat příkazy v seznamu.", "-", "Seznam obsahuje příkaz 'jdi <smer>'.", ""),
        (3, "Sledovat příkazy v seznamu.", "-", "Seznam obsahuje příkaz 'konec'.", ""),
        (4, "Sledovat příkazy v seznamu.", "-", "Seznam obsahuje příkazy 'mluv <jmeno>', 'kviz <jmeno>', 'shop', 'kup <vec>'.", ""),
        (5, "Zadat neznámý příkaz: xyzzy", "xyzzy", "Server odpoví: \"Prikaz 'xyzzy' neznam. Napis 'pomoc'.\"", "Neznámý příkaz"),
    ]
))

# ====== INFRASTRUCTURE ======

cases.append(tc(
    "I1-01",
    "Načtení herního světa z world.json (I1)",
    "Ověřit, že server načítá místnosti, NPC a předměty z externího souboru world.json.",
    "Soubor world.json existuje ve výstupním adresáři projektu (bin/Debug/net8.0/). Server ještě neběží.",
    ".NET 8 runtime. Přístup k výstupnímu adresáři projektu.",
    [
        (1, "Ověřit existenci world.json: spustit v PowerShell: Test-Path SipkovaTulipanka\\bin\\Debug\\net8.0\\world.json", "-", "Příkaz vrátí 'True' – soubor existuje.", ""),
        (2, "Spustit server: dotnet run v SipkovaTulipanka.", "dotnet run", "Server se spustí bez chyby. Log neobsahuje 'world.json not found'.", ""),
        (3, "Přihlásit se jako test_player. Zadat: prozkoumej na Farmě.", "test_player / Test123", "Popis Farmy obsahuje: 'Cervena stodola uprostred zlatych poli.' (odpovídá poli 'description' v world.json).", ""),
        (4, "Zadat: jdi sever (přesun do Lesa).", "jdi sever", "'+== LES ==+' zobrazen – exit farma→sever→les načten z JSON.", ""),
        (5, "Smazat world.json a restartovat server.", "Smazat soubor world.json", "Server spustí záložní BuildWorld() nebo vypíše chybu. Nehavaruje.", "Fallback test"),
    ]
))

cases.append(tc(
    "I2-01",
    "Zápis událostí do souboru server.log (I2)",
    "Ověřit, že server zapisuje timestampované záznamy do souboru server.log.",
    "Server ještě neběží. Výstupní adresář projektu přístupný (bin/Debug/net8.0/).",
    ".NET 8 runtime. Přístup k výstupnímu adresáři.",
    [
        (1, "Spustit server: dotnet run", "dotnet run", "Server se spustí. V adresáři bin/Debug/net8.0/ vznikne (nebo se aktualizuje) soubor server.log.", ""),
        (2, "Přihlásit se jako test_player/Test123.", "test_player / Test123", "Přihlášení proběhne úspěšně.", ""),
        (3, "Zadat: konec pro odpojení.", "konec", "Odpojení proběhne.", ""),
        (4, "Zastavit server (Ctrl+C). Otevřít server.log v textovém editoru.", "-", "Soubor obsahuje záznamy ve formátu '[YYYY-MM-DD HH:MM:SS] ...'", ""),
        (5, "Prohledat log na záznamy o hráči.", "-", "Log obsahuje řádek s textem \"Hrac 'test_player'\" nebo \"Login\" a správný čas události.", ""),
    ]
))

cases.append(tc(
    "I3-01",
    "Obnova uloženého stavu hráče při přihlášení (I3)",
    "Ověřit, že saved_player se přihlásí do správné místnosti a má správný inventář a zlato z players.json.",
    "Server běžící na 127.0.0.1:4000. saved_player/Save123 má v players.json: místnost=vesnice, zlato=25, inventář: [klíč bronzový, pochodeň].",
    DEPS_SAVED,
    [
        (1, "Připojit PuTTY: 127.0.0.1:4000. Zadat: saved_player, stisknout Enter.", "saved_player", "Server zobrazí výzvu 'Heslo: '.", ""),
        (2, "Zadat heslo: Save123", "Save123", "Server zobrazí uvítání 'Vitej, saved_player! Mas 25 zlatych.'", ""),
        (3, "Sledovat zobrazení místnosti.", "-", "Výstup obsahuje '+== VESNICE ==+' – místnost obnovena ze save.", ""),
        (4, "Zadat: inventar", "inventar", "Zobrazí se '[ Inventar ] (2/10) | Zlato: 25'. Inventář obsahuje 'klíč bronzový'.", ""),
        (5, "Ověřit pochodeň v inventáři.", "-", "Inventář dále obsahuje 'pochodeň'. Oba předměty jsou správně obnoveny.", ""),
    ]
))

cases.append(tc(
    "I4-01",
    "Vlastní TCP klient MudClient (I4)",
    "Ověřit, že vlastní program MudClient (projekt MudClient) se úspěšně připojí k serveru a umožní hraní.",
    "Server běžící na 127.0.0.1:4000. Projekt MudClient zkompilován (dotnet build v složce MudClient).",
    ".NET 8 runtime. Projekt MudClient v podsložce MudClient/.",
    [
        (1, "Otevřít PowerShell. Přejít do složky MudClient. Spustit: dotnet run 127.0.0.1 4000", "dotnet run 127.0.0.1 4000", "Konzole zobrazí úvodní banner serveru: 'Vitej v MUD svete! Sipkova Tulipanka'.", ""),
        (2, "Zadat jméno hráče.", "test_player", "Server zobrazí výzvu 'Heslo: '.", ""),
        (3, "Zadat heslo.", "Test123", "Přihlášení úspěšné. Zobrazena Farma (+== FARMA ==+).", ""),
        (4, "Zadat příkaz: pomoc", "pomoc", "Seznam příkazů zobrazen v konzoli MudClient.", ""),
        (5, "Zadat: konec", "konec", "Server odpoví 'Nashledanou, dobrodrhu!' a klient ukončí spojení.", ""),
    ]
))

cases.append(tc(
    "P1-01",
    "Podmínka výhry – vstup do Hradu se 3 klíči (P1)",
    "Ověřit, že hráč s klíčem bronzovým, železným a stříbrným může vstoupit do Hradu a zobrazí se mu vítězná obrazovka.",
    "Server běžící na 127.0.0.1:4000. Hráč musí mít v inventáři: klíč bronzový (kup v obchodu ve Vesnici za 10 zl), klíč železný (kvíz Myslivec, 3. otázka: 'papoušek'), klíč stříbrný (kvíz Horolezec, 3. otázka: '1000'). Předpokládá se, že hráč nasbíral dostatek zlata na nákup (min. 10 zl).",
    DEPS_COMMON + " Pro test P1 použijte účet, který prošel kompletním kvízem Myslivce a Horolezce.",
    [
        (1, "Přihlásit se s hráčem s klíčem bronzovým, železným, stříbrným v inventáři. Ověřit: inventar.", "-", "Inventář obsahuje všechny 3 klíče.", "Příprava"),
        (2, "Přesunout se do Lesa: jdi sever (z Farmy).", "jdi sever", "Hráč v Lese (+== LES ==+).", ""),
        (3, "Zadat: jdi zapad", "jdi zapad", "Server zobrazí 'Jdes zapad...' a pak +== HRAD ==+.", "Vstup do hradu"),
        (4, "Sledovat výstup po vstupu do Hradu.", "-", "Zobrazí se vítězný banner obsahující '*** GRATULACE! VYHRAL/A JSI! ***' a statistiky hráče.", ""),
        (5, "Sledovat statistiky.", "-", "Výstup obsahuje sekci 'STATISTIKY HRACE:' se jménem, časem hry, množstvím zlata a výsledky kvízu.", ""),
    ]
))

# ====== SHOP MECHANIC ======

cases.append(tc(
    "SHOP-01",
    "Příkaz shop mimo Vesnici – chybová hlášení (chybový stav)",
    "Ověřit, že příkaz shop i kup jsou odmítnuty mimo místnost Vesnice a zobrazí srozumitelnou hlášku.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player přihlášen na Farmě (není ve Vesnici).",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Ověřit přítomnost na Farmě.", "test_player / Test123", "+== FARMA ==+ zobrazen.", ""),
        (2, "Zadat: shop", "shop", "Server odpoví: 'Obchod je jen ve Vesnici! Jdi tam nejdrive.'", ""),
        (3, "Zadat: kup pochoden", "kup pochoden", "Server odpoví: 'Nakupovat muzes jen ve Vesnici!'", ""),
        (4, "-", "-", "-", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "SHOP-02",
    "Příkaz shop ve Vesnici – seznam zboží a nákup",
    "Ověřit, že příkaz shop ve Vesnici zobrazí zboží s cenami a příkaz kup úspěšně nakoupí předmět.",
    "Server běžící na 127.0.0.1:4000. saved_player/Save123 ve Vesnici s 25 zlatými.",
    DEPS_SAVED,
    [
        (1, "Přihlásit se jako saved_player/Save123 (startuje ve Vesnici). Zadat: shop", "saved_player / Save123", "Výstup obsahuje '+== OBCHOD ==+' a seznam zboží.", ""),
        (2, "Sledovat seznam zboží.", "-", "Seznam obsahuje řádky: 'lektvar zdravi – 5 zl.', 'pochoden – 3 zl.', 'chleb – 2 zl.', 'klic bronzovy – 10 zl.'", ""),
        (3, "Koupit nejlevnější předmět: kup chleb", "kup chleb", "Server odpoví: 'Koupil/a jsi: chléb za 2 zlatych.' a 'Zbyvajici zlato: 23'", ""),
        (4, "Ověřit inventář: inventar", "inventar", "Inventář zobrazí chléb. Zlato je 23.", ""),
        (5, "Zkusit koupit za nedostatek zlata (test_player, 0 zlata): kup klic bronzovy", "kup klic bronzovy (s 0 zl.)", "Server odpoví: 'Nemas dost zlata! Treba 10, mas 0.'", "Chybový stav"),
    ]
))

# ====== NPC QUIZ MECHANIC ======

cases.append(tc(
    "QUIZ-01",
    "Příkaz kviz s neexistující nebo chybějící postavou (chybové stavy)",
    "Ověřit chybové stavy příkazu kviz: bez jména, s neexistující postavou, s NPC bez kvízu.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player na Farmě.",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123 na Farmě. Zadat: kviz bez jména.", "kviz", "Server odpoví: 'S kym chces delat kviz? Priklad: kviz Princezna'", ""),
        (2, "Zadat kviz s neexistující postavou: kviz drak", "kviz drak", "Server odpoví: \"'drak' tu neni.\"", ""),
        (3, "Zadat kviz s NPC bez kvízu (Pes nemá kvíz): kviz Pes", "kviz Pes", "Server odpoví: 'Pes nema zadny kviz. Zkus 'mluv Pes'.'", "NPC bez kvízu"),
        (4, "-", "-", "-", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "QUIZ-02",
    "Spuštění kvízu s Žábou – první otázka",
    "Ověřit, že příkaz 'kviz Žába' spustí kvíz a zobrazí první otázku.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player přesunut k Jezeru (jdi zapad z Farmy). Žába musí být v místnosti.",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Přesunout na Jezero: jdi zapad", "test_player / Test123, jdi zapad", "Hráč v místnosti U jezera (+== U JEZERA ==+). Postavy obsahují 'Žába (kvíz) (NPC)'.", ""),
        (2, "Pohovořit s Žábou: mluv Zaba", "mluv Zaba", "Dialog Žáby zobrazen. Tip zmíní příkaz 'kviz Žába'.", ""),
        (3, "Spustit kvíz: kviz Zaba", "kviz Zaba", "Server zobrazí: 'Zaba spousti kviz! Odpovez na 3 otazky.' a hint '(Napis 'preskoc' pro preskoceni otazky)'.", ""),
        (4, "Sledovat první otázku.", "-", "Server zobrazí 'Otazka 1/3:' a text otázky 'Kolik noh ma pavouk?'.", ""),
        (5, "-", "-", "-", ""),
    ]
))

cases.append(tc(
    "QUIZ-03",
    "Správná a špatná odpověď v kvízu Žáby",
    "Ověřit správnou odpověď (přírůstek zlata), špatnou odpověď (zobrazení správné) a přeskočení otázky.",
    "Pokračuje po QUIZ-02: hráč je ve kvízu s Žábou, čeká první otázka 'Kolik noh ma pavouk?'.",
    DEPS_COMMON,
    [
        (1, "Kvíz aktivní. Zadat špatnou odpověď: 6", "6", "Server odpoví: 'Spatne. Spravna odpoved: 8'", "Chybový stav"),
        (2, "Druhá otázka se zobrazí automaticky. Zadat správnou odpověď: velryba", "velryba", "Server odpoví: 'Spravne! +6 zlatych. (Celkem: 6)'", ""),
        (3, "Třetí otázka o slepici. Zadat přeskočení: preskoc", "preskoc", "Server odpoví: 'Otazka preskocena.'", ""),
        (4, "Sledovat konec kvízu.", "-", "Server zobrazí: 'Kviz konci! Spravne: 1/3' a 'Celkovy stav: 6 zlatych.'", ""),
        (5, "Ověřit přírůstek zlata: penize", "penize", "Server potvrdí správný stav zlata po kvízu.", ""),
    ]
))

# ====== LOCKED ROOM MECHANIC ======

cases.append(tc(
    "LOCK-01",
    "Vstup do Hradu bez klíčů – zamčená místnost (chybový stav)",
    "Ověřit, že hráč bez požadovaných klíčů nedostane se do Hradu a dostane srozumitelnou hlášku.",
    "Server běžící na 127.0.0.1:4000. Hráč test_player přihlášen v Lese. Inventář prázdný (žádné klíče).",
    DEPS_COMMON,
    [
        (1, "Přihlásit se jako test_player/Test123. Přesunout do Lesa: jdi sever", "test_player / Test123", "Hráč v Lese. Inventář je prázdný (ověřit: inventar).", ""),
        (2, "Zadat: jdi zapad (směr k Hradu)", "jdi zapad", "Server odpoví: \"Vstup do 'Hrad' je zamceny!\"", ""),
        (3, "Sledovat výčet chybějících klíčů.", "-", "Výstup obsahuje: 'Chybi ti tyto klice: klic bronzovy, klic zelezny, klic stribrny'", ""),
        (4, "Sledovat nápovědu pro získání klíčů.", "-", "Výstup obsahuje: 'Klice muzes koupit v obchodu ve Vesnici nebo ziskat od NPC.'", ""),
        (5, "Ověřit, že hráč zůstal v Lese: prozkoumej", "prozkoumej", "+== LES ==+ zobrazen – hráč se nepřesunul.", ""),
    ]
))

cases.append(tc(
    "LOCK-02",
    "Vstup do Hradu se všemi 3 klíči – úspěšný vstup",
    "Ověřit, že hráč se všemi 3 klíči (bronzový, železný, stříbrný) se úspěšně dostane do Hradu.",
    "Hráč musí mít v inventáři: klíč bronzový + klíč železný + klíč stříbrný. Server běžící na 127.0.0.1:4000. Hráč v Lese.",
    "Klíče lze získat: bronzový (shop/Vesnice, 10 zl), železný (kvíz Myslivec, odpověď 'papoušek'), stříbrný (kvíz Horolezec, odpověď '1000').",
    [
        (1, "Přihlásit se s hráčem majícím 3 klíče. Přejít do Lesa. Ověřit: inventar.", "-", "Inventář zobrazí všechny 3 klíče: klíč bronzový, klíč železný, klíč stříbrný.", ""),
        (2, "Zadat: jdi zapad", "jdi zapad", "Server zobrazí 'Jdes zapad...' – hráč projde (klíče ověřeny).", ""),
        (3, "Sledovat zobrazení místnosti.", "-", "Výstup obsahuje '+== HRAD ==+' a popis hradu.", ""),
        (4, "Sledovat vítěznou hlášku (první vstup do Hradu).", "-", "Zobrazí se vítězný banner: '*** GRATULACE! VYHRAL/A JSI! ***'", ""),
        (5, "Zadat: konec pro ukončení.", "konec", "'Nashledanou, dobrodrhu! Stav ulozin.' – stav uložen s příznakem výhry.", ""),
    ]
))

# ============================================================
# GENERATE RTF
# ============================================================
RTF_HEADER = r"""{\rtf1\ansi\ansicpg1250\uc1\deff0\deflang1029
{\fonttbl{\f0\froman\fcharset238\fprq2 Times New Roman;}{\f1\fswiss\fcharset238\fprq2 Calibri;}}
{\colortbl;\red0\green0\blue0;}
\paperw15840\paperh12240\margl1180\margr1500\margt700\margb500\lndscpsxn\widowctrl"""

# Accounts page
BORDER_FULL = (
    r"\clbrdrt\brdrs\brdrw20\brdrcf1"
    r"\clbrdrl\brdrs\brdrw20\brdrcf1"
    r"\clbrdrb\brdrs\brdrw20\brdrcf1"
    r"\clbrdrr\brdrs\brdrw20\brdrcf1"
)
BORDER_FULL_NR = (
    r"\clbrdrt\brdrs\brdrw20\brdrcf1"
    r"\clbrdrl\brdrs\brdrw20\brdrcf1"
    r"\clbrdrb\brdrs\brdrw20\brdrcf1"
    r"\clbrdrr\brdrtbl"
)
SH2 = (
    r"\clvertalc\clbrdrt\brdrs\brdrw10\brdrcf1"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrtbl"
    r"\clshdng2000\cltxlrtb"
)
SH2_LAST = (
    r"\clvertalc\clbrdrt\brdrs\brdrw10\brdrcf1"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrs\brdrw10\brdrcf1"
    r"\clshdng2000\cltxlrtb"
)
SD2 = (
    r"\clvertalc\clbrdrt\brdrtbl"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrtbl"
    r"\cltxlrtb"
)
SD2_LAST = (
    r"\clvertalc\clbrdrt\brdrtbl"
    r"\clbrdrl\brdrs\brdrw10\brdrcf1"
    r"\clbrdrb\brdrs\brdrw10\brdrcf1"
    r"\clbrdrr\brdrs\brdrw10\brdrcf1"
    r"\cltxlrtb"
)

def accounts_page():
    # 4-column account table: Typ hráče | Uživatelské jméno | Heslo | Stav
    W = [3100, 6200, 8600, 13010]
    s = ""
    # Title
    s += f"\n\\trowd\\trleft30\\trftsWidth1\\clbrdrt\\brdrtbl\\clbrdrl\\brdrtbl\\clbrdrb\\brdrtbl\\clbrdrr\\brdrtbl\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\qc{{\\b\\fs40 {r('SPSE Jecna Test Case')}}}\\cell\\row"
    # Subtitle
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_FULL}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\qc{{\\b\\fs28 {r('Šípková Tulipánka – Test Cases')}}}\\cell\\row"
    s += f"\n\\pard\\plain\\ql\\sb100\\par"
    # Server info
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_FULL}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Server: ')}}}127.0.0.1  {{\\b {r('Port: ')}}}4000  {{\\b {r('Protokol: ')}}}TCP (Raw)\\cell\\row"
    s += f"\n\\pard\\plain\\ql\\sb100\\par"
    # Accounts table header
    s += f"\n\\trowd\\trleft30\\trftsWidth1"
    for i, w in enumerate(W):
        border = SH2_LAST if i == len(W)-1 else SH2
        s += f"{border}\\cellx{w}"
    s += f"\n\\pard\\plain\\intbl\\ql{{\\b {r('Typ hráče')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Uživatelské jméno')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Heslo')}}}\\cell"
    s += f"\\pard\\plain\\intbl\\ql{{\\b {r('Stav před testováním')}}}\\cell\\row"
    # Account rows
    accounts = [
        ("Existující hráč", "test_player", "Test123", "Účet existuje. Prázdný inventář. Startovní místnost: Farma. Zlato: 0."),
        ("Hráč s uloženým stavem", "saved_player", "Save123", "Místnost: Vesnice. Zlato: 25. Inventář: klíč bronzový + pochodeň."),
        ("Neexistující hráč", "ghost_player_999", "—", "Účet NESMÍ existovat v players.json před testem."),
        ("Hráč pro registraci", "new_player_001", "New123", "Účet NESMÍ existovat před testem. Bude vytvořen během testu."),
    ]
    for (typ, jmeno, heslo, stav) in accounts:
        s += f"\n\\trowd\\trleft30\\trftsWidth1"
        for i, w in enumerate(W):
            border = SD2_LAST if i == len(W)-1 else SD2
            s += f"{border}\\cellx{w}"
        s += f"\n\\pard\\plain\\intbl\\ql {r(typ)}\\cell"
        s += f"\\pard\\plain\\intbl\\ql {r(jmeno)}\\cell"
        s += f"\\pard\\plain\\intbl\\ql {r(heslo)}\\cell"
        s += f"\\pard\\plain\\intbl\\ql {r(stav)}\\cell\\row"
    # Mechanic note
    s += f"\n\\pard\\plain\\ql\\sb200\\par"
    s += f"\n\\trowd\\trleft30\\trftsWidth1{BORDER_FULL}\\cltxlrtb\\cellx13010"
    s += f"\n\\pard\\plain\\intbl\\ql\\li120{{\\b {r('Implementované mechaniky: ')}}}obchod/nakupování (M – Shop), kvíz s NPC (M – Quiz), zamčené místnosti a klíče (M – Locked Room)\\cell\\row"
    s += "\n\\page"
    return s

# Build complete RTF
out = io.StringIO()
out.write(RTF_HEADER)
out.write("\n")
out.write(accounts_page())
for case in cases:
    out.write(case)
out.write("\n}")

content = out.getvalue()

# Write as cp1250 bytes (the \'XX sequences are ASCII, everything else should be ASCII-safe after rtf_str())
with open("VzorTestu.rtf", "w", encoding="ascii", errors="replace") as f:
    f.write(content)

print(f"Generated VzorTestu.rtf ({len(content)} chars, {len(cases)} test cases)")
