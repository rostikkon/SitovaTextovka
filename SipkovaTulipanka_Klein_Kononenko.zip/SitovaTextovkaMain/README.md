# Šípková Tulipánka – MUD server

**Autoři:** Maximilian Johannes Klein, Rostystav Kononenko  
**Odpovědnosti:** serverová logika, herní svět, klient, komunikační protokol, testování

---

## Herní koncept

Zprávy jsou v češtině.
NPC mohou dávat úkoly – jednoduché otázky. Pokud hráč odpoví správně, dostane peníze nebo předměty.

### Zvolené mechaniky

- **Obchodování** – souvisí s postupem hry
- **Proměnné dialogy s NPC** – NPC nabídne, zda hráč chce úkol; takto si lze vydělat peníze
- **Používání předmětů** – hráč může předměty použít ke ztížení úkolů
- **Úkoly / questy** – jednoduché otázky za odměnu (peníze, předměty)
- **Zamčené místnosti a klíče** – nutné k dosažení konce hry

### Cíl hry

Najít všechny 3 klíče a osvobodit Tulipánku. Plnit questy a odpovídat na otázky od NPC postav.

### Téma hry

Středověk v Čechách.

---

## Mapa herního světa

*(Klíče drží: Myslivec – železný, Horolezec – stříbrný, Obchodník v Tržišti – bronzový za 10 gold)*

---

## README

### O projektu

**Šípková Tulipánka** je školní projekt – textová síťová hra (MUD, Multi-User Dungeon) napsaná v C# (.NET 8).  
Server přijímá více klientů současně přes TCP. Hráči se připojují přes PuTTY nebo přiloženého konzolového klienta.

Hra se odehrává ve středověkém světě. Cílem je nasbírat tři klíče od NPC postav (plněním questů nebo obchodem) a vstoupit do Hradu, kde se ukrývá uvězněná Šípková Tulipánka.

---

### Spuštění serveru

**Přes Visual Studio:**
1. Nastav `SipkovaTulipanka` jako Startup Project
2. Stiskni **F5**

**Přes terminál:**
```
cd SipkovaTulipanka
dotnet run
```

Server naslouchá na portu **4000**.

---

### Připojení přes PuTTY

| Pole | Hodnota |
|------|---------|
| Host Name | `127.0.0.1` |
| Port | `4000` |
| Connection type | `Raw` |

Nebo spusť přiloženého klienta:
```
cd MudClient
dotnet run
```

---

### Testovací účty

| Přihlašovací jméno | Heslo |
|--------------------|-------|
| `test_player` | `Test123` |
| `saved_player` | `Save123` |

---

### Struktura projektu

```
SitovaTextovkaMain/
├── SipkovaTulipanka/   ← server (MudServer.exe)
│   ├── world.json      ← herní svět (místnosti, předměty, NPC)
│   ├── players.json    ← uložené stavy hráčů
│   └── server.log      ← log připojení a příkazů
├── MudClient/          ← konzolový klient
├── MudTester/          ← automatické testy
└── set.md              ← tento soubor
```

---

### Implementované funkce

| Kód | Popis |
|-----|-------|
| I1 | Načítání herního světa z `world.json` |
| I2 | Logování do `server.log` s časovou značkou |
| I3 | Účty, SHA-256 hesla, persistence stavu hráče |
| I4 | Vlastní konzolový klient (`MudClient`) |
| P1 | Podmínka výhry (vstup do Hradu se 3 klíči), statistiky |

---

### Příkazy ve hře

| Příkaz | Popis |
|--------|-------|
| `jdi <místnost>` | Přesun do místnosti |
| `prozkoumej` | Popis místnosti, předměty, NPC, hráči |
| `vezmi <předmět>` | Vzít předmět do inventáře |
| `poloz <předmět>` | Odložit předmět |
| `inventar` | Zobrazit obsah inventáře |
| `mluv <NPC>` | Zahájit dialog s NPC |
| `stat` | Zobrazit statistiky hráče |
| `pomoc` | Seznam všech příkazů |
| `odejdi` | Odpojit se |
