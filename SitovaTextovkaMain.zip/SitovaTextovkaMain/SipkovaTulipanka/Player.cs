// ============================================================
// Player.cs
// ============================================================

namespace MudServer;

using System.Net.Sockets;
using System.Text;

public class Player
{
    public string Name { get; private set; } = "Neznámý";
    public Room CurrentRoom { get; private set; }

    private readonly List<Item> _inventory = new();
    private const int MaxInventorySize = 10;
    private int _gold = 0;
    private bool _hasWon = false;

    // Session statistiky
    private DateTime _sessionStart;
    private int _sessionQuizCorrect = 0;
    private int _sessionQuizTotal = 0;

    // Příznak úspěšného přihlášení – chráníme save při chybě loginu
    private bool _isLoggedIn = false;

    // Aktivní kvíz
    private Npc? _activeQuizNpc = null;
    private int _activeQuestionIndex = 0;
    private int _quizCorrect = 0;

    private readonly NetworkStream _stream;
    private readonly StreamReader _reader;
    private readonly StreamWriter _writer;
    private readonly GameWorld _world;
    private readonly AccountManager _accounts;
    private PlayerSave _save = new();

    public Player(TcpClient client, GameWorld world, AccountManager accounts)
    {
        _world = world;
        _accounts = accounts;
        CurrentRoom = world.StartRoom;

        _stream = client.GetStream();
        _reader = new StreamReader(_stream, Encoding.UTF8, leaveOpen: true);
        _writer = new StreamWriter(_stream, Encoding.UTF8, leaveOpen: true)
        {
            AutoFlush = true,
            NewLine = "\r\n"
        };
    }

    // =========================================================
    // HLAVNÍ SMYČKA
    // =========================================================
    public async Task HandleAsync()
    {
        try
        {
            await SendLineAsync("=========================================");
            await SendLineAsync("   Vitej v MUD svete! Sipkova Tulipanka  ");
            await SendLineAsync("=========================================");

            // I3 – Login flow
            bool loggedIn = await LoginFlowAsync();
            if (!loggedIn) return;

            _sessionStart = DateTime.Now;
            _world.AddPlayer(this);

            await SendLineAsync($"\nVitej, {Name}! Mas {_gold} zlatych.");
            await SendLineAsync("Tip: napis 'pomoc' pro seznam prikazu.\n");

            // P1 – Pokud hráč již vyhrál, zobrazit informaci
            if (_hasWon)
                await SendLineAsync("[!] Jiz jsi zachranil/a Tulipanku! Cil splnen, ale muzis hrat dal.\n");

            await ShowRoomAsync();

            while (true)
            {
                await _writer.WriteAsync("\n> ");
                string? line = await _reader.ReadLineAsync();
                if (line == null) break;

                string input = line.Trim();
                if (string.IsNullOrEmpty(input)) continue;

                if (_activeQuizNpc != null)
                {
                    await HandleQuizAnswerAsync(input);
                    continue;
                }

                bool quit = await ProcessCommandAsync(input);
                if (quit) break;
            }
        }
        catch (IOException)
        {
            Logger.Log($"[{Name}] Náhlé přerušení spojení.");
        }
        catch (Exception ex)
        {
            Logger.Log($"[{Name}] Chyba: {ex.Message}");
        }
        finally
        {
            if (_isLoggedIn) SavePlayerState();
            _accounts.Logout(Name);
            _world.RemovePlayer(Name);
            _reader.Dispose();
            _writer.Dispose();
            _stream.Dispose();
            Logger.Log($"[Server] Hráč '{Name}' se odpojil.");
        }
    }

    // =========================================================
    // I3 – LOGIN / REGISTRACE
    // =========================================================
    private async Task<bool> LoginFlowAsync()
    {
        while (true)
        {
            await SendAsync("Uzivatelske jmeno: ");
            string? input = await _reader.ReadLineAsync();
            if (input == null) return false;

            string username = input.Trim();
            if (string.IsNullOrEmpty(username)) continue;

            // Zkontrolovat, zda není hráč již přihlášen
            if (_accounts.IsLoggedIn(username))
            {
                await SendLineAsync($"Hrac '{username}' je jiz prihlaseny! Zkus jine jmeno.");
                continue;
            }

            if (_accounts.AccountExists(username))
            {
                // Existující účet – ověření hesla
                bool authenticated = false;
                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    await SendAsync("Heslo: ");
                    string? pwd = await _reader.ReadLineAsync();
                    if (pwd == null) return false;

                    if (_accounts.TryLogin(username, pwd.Trim()))
                    {
                        authenticated = true;
                        break;
                    }

                    int remaining = 3 - attempt;
                    if (remaining > 0)
                        await SendLineAsync($"Spatne heslo. Zbyvaji {remaining} pokusy.");
                }

                if (!authenticated)
                {
                    await SendLineAsync("Prilis mnoho spatnych pokusu. Odpojuji.");
                    Logger.Log($"[Přihlášení] Zamítnuto '{username}' – příliš mnoho chyb.");
                    return false;
                }
            }
            else
            {
                // Neexistující účet – nabídnout registraci
                await SendLineAsync($"Ucet '{username}' nenalezen.");
                await SendAsync("Zaregistrovat novy ucet? (ano/ne): ");
                string? answer = await _reader.ReadLineAsync();
                if (answer == null) return false;

                if (TextHelper.Normalize(answer.Trim()) != "ano")
                {
                    await SendLineAsync("Nashledanou!");
                    return false;
                }

                // Registrace nového účtu
                string? newPassword = null;
                while (newPassword == null)
                {
                    await SendAsync("Nove heslo (min. 4 znaky): ");
                    string? p1 = await _reader.ReadLineAsync();
                    if (p1 == null) return false;
                    p1 = p1.Trim();

                    if (p1.Length < 4)
                    {
                        await SendLineAsync("Heslo je prilis kratke. Zkus znovu.");
                        continue;
                    }

                    await SendAsync("Potvrdte heslo: ");
                    string? p2 = await _reader.ReadLineAsync();
                    if (p2 == null) return false;

                    if (p1 != p2.Trim())
                    {
                        await SendLineAsync("Hesla se neshoduji. Zkus znovu.");
                        continue;
                    }

                    newPassword = p1;
                }

                if (!_accounts.Register(username, newPassword))
                {
                    await SendLineAsync("Chyba pri registraci. Zkus jine jmeno.");
                    continue;
                }
                _accounts.TryLogin(username, newPassword);
                await SendLineAsync($"Ucet '{username}' uspesne vytvoren!");
            }

            // Načíst uložený stav
            _save = _accounts.GetSave(username) ?? new PlayerSave { Username = username };
            Name = _save.Username;
            _gold = _save.Gold;
            _hasWon = _save.HasWon;

            // Obnovit inventář
            foreach (var si in _save.Inventory)
                _inventory.Add(new Item(si.Name, si.Description));

            // Obnovit místnost
            Room? savedRoom = _world.GetRoomByKey(_save.RoomKey);
            CurrentRoom = savedRoom ?? _world.StartRoom;

            _isLoggedIn = true;
            Logger.Log($"[Login] Hráč '{Name}' přihlášen. Místnost: {CurrentRoom.Name}, Zlato: {_gold}");
            return true;
        }
    }

    // =========================================================
    // ULOŽENÍ STAVU HRÁČE (I3)
    // =========================================================
    private void SavePlayerState()
    {
        var updatedSave = new PlayerSave
        {
            Username = _save.Username,
            PasswordHash = _save.PasswordHash,
            Gold = _gold,
            RoomKey = CurrentRoom.Key,
            Inventory = _inventory
                .Select(i => new SavedItem { Name = i.Name, Description = i.Description })
                .ToList(),
            HasWon = _hasWon,
            QuizCorrect = _save.QuizCorrect + _sessionQuizCorrect,
            QuizTotal = _save.QuizTotal + _sessionQuizTotal
        };
        _accounts.UpdateSave(updatedSave);
        Logger.Log($"[Save] Uložen stav hráče '{Name}': zlato={_gold}, místnost={CurrentRoom.Key}");
    }

    // =========================================================
    // ZPRACOVÁNÍ PŘÍKAZŮ
    // =========================================================
    private async Task<bool> ProcessCommandAsync(string input)
    {
        string norm = TextHelper.Normalize(input);
        string[] parts = norm.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
        string verb = parts[0];
        string arg = parts.Length > 1 ? parts[1].Trim() : "";

        switch (verb)
        {
            case "jdi":
            case "go":
                await MoveAsync(arg); break;

            case "prozkoumej":
            case "look":
            case "p":
                await ShowRoomAsync(); break;

            case "vezmi":
            case "take":
                await TakeItemAsync(arg); break;

            case "poloz":
            case "drop":
                await DropItemAsync(arg); break;

            case "inventar":
            case "inv":
            case "i":
                await ShowInventoryAsync(); break;

            case "penize":
            case "zlato":
            case "gold":
                await SendLineAsync($"Mas {_gold} zlatych."); break;

            case "mluv":
            case "talk":
                await TalkToNpcAsync(arg); break;

            case "kviz":
            case "quiz":
                await StartQuizAsync(arg); break;

            case "shop":
            case "obchod":
                await ShowShopAsync(); break;

            case "kup":
            case "buy":
                await BuyItemAsync(arg); break;

            case "pomoc":
            case "help":
            case "?":
                await ShowHelpAsync(); break;

            case "statistiky":
            case "stats":
                await ShowStatsAsync(); break;

            case "konec":
            case "quit":
            case "exit":
                await SendLineAsync("Nashledanou, dobrodrhu! Stav ulozin.");
                return true;

            default:
                await SendLineAsync($"Prikaz '{verb}' neznam. Napis 'pomoc'."); break;
        }
        return false;
    }

    // =========================================================
    // POHYB
    // =========================================================
    private async Task MoveAsync(string direction)
    {
        if (string.IsNullOrEmpty(direction))
        {
            await SendLineAsync("Kam chces jit? Priklad: jdi sever");
            return;
        }

        if (!CurrentRoom.Exits.TryGetValue(direction, out Room? target))
        {
            await SendLineAsync($"Smer '{direction}' odsud nevede. Dostupne: " +
                string.Join(", ", CurrentRoom.Exits.Keys));
            return;
        }

        // Kontrola zamčené místnosti (Hrad – 3 klíče)
        if (target.RequiredKeys > 0)
        {
            var requiredKeys = _world.HradKeys;
            var missing = requiredKeys
                .Where(k => !_inventory.Any(i => TextHelper.Normalize(i.Name) == k))
                .ToList();

            if (missing.Count > 0)
            {
                await SendLineAsync($"Vstup do '{target.Name}' je zamceny!");
                await SendLineAsync($"Chybi ti tyto klice: {string.Join(", ", missing)}");
                await SendLineAsync("Klice muzes koupit v obchodu ve Vesnici nebo ziskat od NPC.");
                return;
            }
        }

        CurrentRoom = target;
        await SendLineAsync($"Jdes {direction}...");
        await ShowRoomAsync();

        // P1 – Podmínka výhry: vstup do Hradu s všemi klíči
        if (target.Key == "hrad" && !_hasWon)
        {
            _hasWon = true;
            await ShowVictoryAsync();
        }
    }

    // =========================================================
    // P1 – VÝHRA / KONEC HRY
    // =========================================================
    private async Task ShowVictoryAsync()
    {
        var elapsed = DateTime.Now - _sessionStart;
        string time = elapsed.TotalMinutes >= 1
            ? $"{(int)elapsed.TotalMinutes} min {elapsed.Seconds} sek"
            : $"{elapsed.Seconds} sek";

        int totalCorrect = _save.QuizCorrect + _sessionQuizCorrect;
        int totalTotal = _save.QuizTotal + _sessionQuizTotal;

        await SendLineAsync("""

            +==============================================+
            |                                              |
            |        *** GRATULACE! VYHRAL/A JSI! ***      |
            |                                              |
            |  Nashel/a jsi vsechny 3 klice a vstoupil/a  |
            |  do hradu! Tulipanka je zachranena!          |
            |  Sipkova Tulipanka se probouzi ze sna...     |
            |                                              |
            +==============================================+
            """);

        await SendLineAsync("STATISTIKY HRACE:");
        await SendLineAsync($"  Jmeno:          {Name}");
        await SendLineAsync($"  Cas hry:        {time}");
        await SendLineAsync($"  Zlato:          {_gold}");
        await SendLineAsync($"  Kviz spravne:   {totalCorrect}/{totalTotal}");
        await SendLineAsync($"  Mistnost:       {CurrentRoom.Name}");
        await SendLineAsync("\nMuzis hrat dal, prohledat hrad a mluvit s Tulipankou!");
        await SendLineAsync("(Prikaz 'konec' pro ukonceni)\n");

        Logger.Log($"[Výhra] Hráč '{Name}' dokončil hru! Čas: {time}, Zlato: {_gold}");
    }

    private async Task ShowStatsAsync()
    {
        var elapsed = DateTime.Now - _sessionStart;
        string time = elapsed.TotalMinutes >= 1
            ? $"{(int)elapsed.TotalMinutes} min {elapsed.Seconds} sek"
            : $"{elapsed.Seconds} sek";

        int totalCorrect = _save.QuizCorrect + _sessionQuizCorrect;
        int totalTotal = _save.QuizTotal + _sessionQuizTotal;

        await SendLineAsync($"\n[ STATISTIKY ]");
        await SendLineAsync($"  Hrac:           {Name}");
        await SendLineAsync($"  Cas hry:        {time}");
        await SendLineAsync($"  Zlato:          {_gold}");
        await SendLineAsync($"  Kviz spravne:   {totalCorrect}/{totalTotal}");
        await SendLineAsync($"  Predmety:       {_inventory.Count}/{MaxInventorySize}");
        await SendLineAsync($"  Mistnost:       {CurrentRoom.Name}");
        await SendLineAsync($"  Cil splnen:     {(_hasWon ? "ANO" : "NE")}");
    }

    // =========================================================
    // KVÍZ
    // =========================================================
    private async Task StartQuizAsync(string npcName)
    {
        if (string.IsNullOrEmpty(npcName))
        {
            await SendLineAsync("S kym chces delat kviz? Priklad: kviz Princezna");
            return;
        }

        Npc? npc = CurrentRoom.Npcs
            .FirstOrDefault(n => TextHelper.Match(n.Name, npcName));

        if (npc == null)
        {
            await SendLineAsync($"'{npcName}' tu neni.");
            return;
        }

        if (!npc.HasQuiz)
        {
            await SendLineAsync($"{npc.Name} nema zadny kviz. Zkus 'mluv {npcName}'.");
            return;
        }

        _activeQuizNpc = npc;
        _activeQuestionIndex = 0;
        _quizCorrect = 0;

        await SendLineAsync($"\n{npc.Name} spousti kviz! Odpovez na {npc.Questions.Count} otazky.");
        await SendLineAsync("(Napis 'preskoc' pro preskoceni otazky)\n");
        await AskCurrentQuestionAsync();
    }

    private async Task AskCurrentQuestionAsync()
    {
        if (_activeQuizNpc == null) return;
        var q = _activeQuizNpc.Questions[_activeQuestionIndex];
        await SendLineAsync($"Otazka {_activeQuestionIndex + 1}/{_activeQuizNpc.Questions.Count}:");
        await SendLineAsync($"  {q.Text}");
    }

    private async Task HandleQuizAnswerAsync(string answer)
    {
        if (_activeQuizNpc == null) return;

        string norm = TextHelper.Normalize(answer);
        _sessionQuizTotal++;

        if (norm == "preskoc")
        {
            await SendLineAsync("Otazka preskocena.");
        }
        else
        {
            var q = _activeQuizNpc.Questions[_activeQuestionIndex];
            if (q.Check(answer))
            {
                _gold += q.Reward;
                _quizCorrect++;
                _sessionQuizCorrect++;
                await SendLineAsync($"Spravne! +{q.Reward} zlatych. (Celkem: {_gold})");

                if (q.ItemReward != null)
                {
                    if (_inventory.Count < MaxInventorySize)
                    {
                        _inventory.Add(new Item(q.ItemReward.Name, q.ItemReward.Description));
                        await SendLineAsync($"  *** Ziskal/a jsi: {q.ItemReward.Name}! ***");
                    }
                    else
                    {
                        await SendLineAsync($"  Inventar je plny! {q.ItemReward.Name} si nevzal/a.");
                    }
                }
            }
            else
            {
                await SendLineAsync($"Spatne. Spravna odpoved: {q.Answer}");
            }
        }

        _activeQuestionIndex++;

        if (_activeQuestionIndex >= _activeQuizNpc.Questions.Count)
        {
            await SendLineAsync($"\nKviz konci! Spravne: {_quizCorrect}/{_activeQuizNpc.Questions.Count}");
            await SendLineAsync($"Celkovy stav: {_gold} zlatych.");
            _activeQuizNpc = null;
        }
        else
        {
            await AskCurrentQuestionAsync();
        }
    }

    // =========================================================
    // SHOP
    // =========================================================
    private async Task ShowShopAsync()
    {
        if (TextHelper.Normalize(CurrentRoom.Name) != "vesnice")
        {
            await SendLineAsync("Obchod je jen ve Vesnici! Jdi tam nejdrive.");
            return;
        }
        await SendLineAsync(_world.Shop.Describe());
        await SendLineAsync($"Tvoje zlato: {_gold}");
    }

    private async Task BuyItemAsync(string itemName)
    {
        if (TextHelper.Normalize(CurrentRoom.Name) != "vesnice")
        {
            await SendLineAsync("Nakupovat muzes jen ve Vesnici!");
            return;
        }

        if (string.IsNullOrEmpty(itemName))
        {
            await SendLineAsync("Co chces koupit? Priklad: kup pochoden");
            return;
        }

        ShopItem? shopItem = _world.Shop.Items
            .FirstOrDefault(s => TextHelper.Match(s.Name, itemName));

        if (shopItem == null)
        {
            await SendLineAsync($"'{itemName}' v obchodu neni. Napis 'shop' pro seznam.");
            return;
        }

        if (_inventory.Count >= MaxInventorySize)
        {
            await SendLineAsync("Inventar je plny! Poloz nejaky predmet.");
            return;
        }

        if (_gold < shopItem.Price)
        {
            await SendLineAsync($"Nemas dost zlata! Treba {shopItem.Price}, mas {_gold}.");
            return;
        }

        _gold -= shopItem.Price;
        _inventory.Add(new Item(shopItem.Name, shopItem.Description));
        await SendLineAsync($"Koupil/a jsi: {shopItem.Name} za {shopItem.Price} zlatych.");
        await SendLineAsync($"Zbyvajici zlato: {_gold}");
    }

    // =========================================================
    // OSTATNÍ AKCE
    // =========================================================
    private async Task ShowRoomAsync()
    {
        var others = _world.GetPlayersInRoom(CurrentRoom, Name);
        await SendLineAsync(CurrentRoom.Describe(others));
    }

    private async Task TalkToNpcAsync(string npcName)
    {
        if (string.IsNullOrEmpty(npcName))
        {
            await SendLineAsync("S kym chces mluvit? Priklad: mluv Farmar");
            return;
        }

        Npc? npc = CurrentRoom.Npcs
            .FirstOrDefault(n => TextHelper.Match(n.Name, npcName));

        if (npc == null)
        {
            await SendLineAsync($"'{npcName}' tu neni.");
            return;
        }

        await SendLineAsync(npc.Speak());
        if (npc.HasQuiz)
            await SendLineAsync($"  (Tip: prikaz 'kviz {npc.Name}' pro kviz s odmenou!)");
    }

    private async Task TakeItemAsync(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
        {
            await SendLineAsync("Co chces vzit? Priklad: vezmi jablko");
            return;
        }

        if (_inventory.Count >= MaxInventorySize)
        {
            await SendLineAsync($"Inventar je plny! ({MaxInventorySize}/{MaxInventorySize})");
            return;
        }

        Item? found = CurrentRoom.Items
            .FirstOrDefault(i => TextHelper.Match(i.Name, itemName));

        if (found == null)
        {
            await SendLineAsync($"Predmet '{itemName}' tu nevidim.");
            return;
        }

        CurrentRoom.Items.Remove(found);
        _inventory.Add(found);
        await SendLineAsync($"Vzal/a jsi: {found.Name}");
    }

    private async Task DropItemAsync(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
        {
            await SendLineAsync("Co chces polozit? Priklad: poloz lano");
            return;
        }

        Item? found = _inventory
            .FirstOrDefault(i => TextHelper.Match(i.Name, itemName));

        if (found == null)
        {
            await SendLineAsync($"'{itemName}' nemas u sebe.");
            return;
        }

        _inventory.Remove(found);
        CurrentRoom.Items.Add(found);
        await SendLineAsync($"Polozil/a jsi: {found.Name}");
    }

    private async Task ShowInventoryAsync()
    {
        var sb = new StringBuilder();
        sb.AppendLine($"\n[ Inventar ] ({_inventory.Count}/{MaxInventorySize}) | Zlato: {_gold}");

        if (_inventory.Count == 0)
            sb.AppendLine("  Nic u sebe nemas.");
        else
            foreach (var item in _inventory)
                sb.AppendLine($"  * {item.Name} - {item.Description}");

        await SendLineAsync(sb.ToString());
    }

    private async Task ShowHelpAsync()
    {
        await SendLineAsync("""

            +=========================================+
            |           SEZNAM PRIKAZU                |
            +=========================================+
            | jdi <smer>       Pohyb (sever,jih...)  |
            | prozkoumej       Prohledni mistnost     |
            | vezmi <vec>      Vezmi predmet          |
            | poloz <vec>      Poloz predmet          |
            | inventar         Zobraz inventar        |
            | penize           Kolik mas zlata        |
            | mluv <jmeno>     Mluv s postavou        |
            | kviz <jmeno>     Kviz s NPC za zlato    |
            | shop             Zobraz obchod          |
            | kup <vec>        Kup predmet v obchode  |
            | statistiky       Zobraz sve statistiky  |
            | pomoc            Tato napoveda          |
            | konec            Odpojit se (uklada!)   |
            +=========================================+
            | CIL: Najdi 3 klice a vstup do Hradu!    |
            | KLICE: klic bronzovy (obchod, 10 zl.)   |
            |        klic zelezny  (Myslivec - kviz)  |
            |        klic stribrny (Horolezec - kviz) |
            +=========================================+
            """);
    }

    private async Task SendLineAsync(string text)
        => await _writer.WriteLineAsync(text);

    private async Task SendAsync(string text)
        => await _writer.WriteAsync(text);
}
