# CHANGES – Šípková Tulipánka MUD

Datum: 2026-05-06  
Autor revize: Claude Code (Sonnet 4.6)

---

## Opravené chyby (Bug Fixes)

### BF-1 – Překlep ve jménu NPC Vesničan
- **Soubor:** `GameWorld.cs`
- **Problém:** NPC se jmenoval `"Vesnicanee"` (dva e) → příkaz `mluv Vesnicanee` a `kviz Vesnicanee` nefungoval intuitivně.
- **Oprava:** Přejmenováno na `"Vesničan"` (správný tvar).

### BF-2 – Nepoužitý using System.Numerics
- **Soubor:** `MudTcpServer.cs`
- **Problém:** `using System.Numerics;` byl importován, ale nikde nevyužit.
- **Oprava:** Odstraněn.

### BF-3 – Biologicky nesprávná otázka Žáby
- **Soubor:** `GameWorld.cs` / `world.json`
- **Problém:** Otázka „Kolik žaber má zlatá rybka?" s odpovědí „0" – zlatá rybka žábry má.
- **Oprava:** Otázka změněna na „Kolik vajec snese slepice přibližně za rok?" → odpověď „300".

### BF-4 – Záchrana stavu při přerušeném loginu
- **Soubor:** `Player.cs`
- **Problém:** `SavePlayerState()` se volal i při neúspěšném loginu, což by uložilo prázdný záznam.
- **Oprava:** Přidán příznak `_isLoggedIn`; stav se ukládá jen po úspěšném přihlášení.

### BF-5 – Sdílení reference v AccountManager
- **Soubor:** `AccountManager.cs`
- **Problém:** `GetSave()` by mohla vrátit referenci na interní objekt, který by mohl být přepsán jiným vláknem.
- **Oprava:** `GetSave()` vrací hlubokou kopii (`DeepCopy`).

---

## Nové funkce

### I2 – Logování s časovými značkami do souboru
- **Nový soubor:** `Logger.cs`
- **Popis:** Statická třída `Logger.Log(string)` zapisuje každou zprávu do konzole A do souboru `server.log` ve formátu `[YYYY-MM-DD HH:MM:SS] zpráva`.
- **Thread-safe:** Zápis do souboru je chráněn `lock`.
- **Použití:** Nahrazuje všechna volání `Console.WriteLine` v serverovém kódu.
- **Log soubor:** `bin/Debug/net8.0/server.log`

### I3 – Přihlášení a persistence hráče
- **Nový soubor:** `AccountManager.cs`
- **Nový soubor:** `WorldDto.cs` (pomocné třídy)
- **Popis:**
  - Hráč se musí přihlásit při každém připojení.
  - Pokud účet existuje: ověření hesla (max. 3 pokusy).
  - Pokud účet neexistuje: nabídka registrace.
  - Hesla hashována pomocí **SHA-256**.
  - Stav hráče (místnost, inventář, zlato, výhra, kvíz statistiky) ukládán do `players.json`.
  - Po zadání `konec` nebo při odpojení: automatické uložení stavu.
  - Ochrana před duplicitním přihlášením (stejný účet 2× současně).
- **Předsazené testovací účty** (vytvořeny automaticky při startu):
  - `test_player` / `Test123`
  - `saved_player` / `Save123` (s 25 zlatými, v místnosti Vesnice, 2 předměty)

### I1 – Načítání herního světa z JSON souboru
- **Nový soubor:** `world.json` – kompletní herní svět ve formátu JSON
- **Nový soubor:** `WorldDto.cs` – DTO třídy pro deserializaci
- **Modifikován:** `GameWorld.cs` – přidána metoda `LoadFromJson(path)`
- **Popis:**
  - Server se při startu pokusí načíst `world.json` z výstupního adresáře.
  - Pokud soubor existuje: načte místnosti, NPC, otázky, předměty, obchod a klíče hradu.
  - Pokud soubor neexistuje: použije záložní metodu `BuildWorld()` (původní kód).
  - `world.json` se automaticky kopíruje do `bin/` při buildu (nastaveno v `.csproj`).
- **JSON struktura:** `rooms[]`, `npcs[]`, `questions[]`, `itemReward`, `shop`, `hradKeys[]`

### P1 – Dokončení hry (podmínka výhry, oznámení, statistiky)
- **Modifikován:** `Player.cs`
- **Popis:**
  - Podmínka výhry: hráč vstoupí do místnosti **Hrad** se všemi 3 klíči.
  - Zobrazeno ASCII oznámení „GRATULACE! VYHRAL/A JSI!".
  - Statistiky: jméno, čas hry, zlato, kvíz správně/celkem.
  - Výhra se uloží do účtu (`HasWon = true`).
  - Po výhře lze pokračovat ve hře.
  - Nový příkaz `statistiky` (alias `stats`) pro zobrazení statistik kdykoli.

### I4 – Vlastní klientský program
- **Nový adresář:** `MudClient/`
- **Nový soubor:** `MudClient/Program.cs`
- **Nový soubor:** `MudClient/MudClient.csproj`
- **Popis:** Konzolový TCP klient pro připojení k MUD serveru.
- **Použití:**
  ```
  cd MudClient
  dotnet run localhost 4000
  dotnet run 192.168.1.5 4000
  ```
- **Funkce:** Asynchronní čtení ze serveru a odesílání vstupu. Podpora Ctrl+C pro odpojení.

---

## Vylepšení herního světa

### HE-1 – Přidána NPC Tulipánka
- **Soubor:** `world.json`, `GameWorld.cs`
- **Popis:** Přidána postava Tulipánky do místnosti Hrad – cíl celé hry (osvobozená Šípková Tulipánka).

### HE-2 – Opravená otázka Horolezce
- **Soubor:** `world.json`, `GameWorld.cs`
- **Starý text:** „Ve které zemi jsou Alpy?" – Alpy jsou v 8 zemích, špatná otázka.
- **Nový text:** „Ve které zemi leží Matterhorn?" – jednoznačná odpověď: Švýcarsko.

### HE-3 – Diakritika v textech místností a NPC
- **Soubor:** `GameWorld.cs`, `world.json`
- **Popis:** Texty místností a NPC nyní mají správnou českou diakritiku.

### HE-4 – Nový příkaz `statistiky`
- **Soubor:** `Player.cs`
- **Popis:** Hráč může kdykoli zadat `statistiky` (nebo `stats`) pro zobrazení aktuálních statistik.

---

## Technické změny

### TC-1 – Room.Key property
- **Soubor:** `GameWorld.cs`
- **Popis:** Třída `Room` má nové pole `Key` (string) pro identifikaci místnosti při ukládání pozice hráče.

### TC-2 – HradKeys: static → instance property
- **Soubor:** `GameWorld.cs`, `Player.cs`
- **Popis:** `GameWorld.HradKeys` přesunuto ze `static readonly` na instanční vlastnost, aby mohlo být nastaveno z `world.json`.

### TC-3 – AccountManager.IsLoggedIn()
- **Soubor:** `AccountManager.cs`
- **Popis:** Přidána ochrana před duplicitním přihlášením stejného účtu.

### TC-4 – Logger.Log() nahrazuje Console.WriteLine
- **Soubory:** `MudTcpServer.cs`, `Program.cs`, `GameWorld.cs`, `AccountManager.cs`, `Player.cs`
- **Popis:** Veškeré serverové výpisy nyní jdou přes `Logger.Log()` a ukládají se do souboru.

### TC-5 – Seedování testovacích účtů
- **Soubor:** `AccountManager.cs`
- **Popis:** Při startu serveru se automaticky vytvoří testovací účty (pokud neexistují): `test_player/Test123`, `saved_player/Save123`.

---

## Přehled souborů

| Soubor | Stav | Popis |
|--------|------|-------|
| `Logger.cs` | **NOVÝ** | I2 – Logování do souboru |
| `AccountManager.cs` | **NOVÝ** | I3 – Účty, hesla (SHA-256), persistence |
| `WorldDto.cs` | **NOVÝ** | I1 – DTO pro JSON deserializaci |
| `world.json` | **NOVÝ** | I1 – Herní svět v JSON |
| `MudClient/Program.cs` | **NOVÝ** | I4 – Vlastní klientský program |
| `MudClient/MudClient.csproj` | **NOVÝ** | I4 – Projekt klienta |
| `GameWorld.cs` | **UPRAVEN** | I1, oprava Vesničan, Tulipánka, Room.Key |
| `Player.cs` | **UPRAVEN** | I3 login flow, P1 výhra, statistiky |
| `MudTcpServer.cs` | **UPRAVEN** | AccountManager, odstraněn unused import |
| `Program.cs` | **UPRAVEN** | AccountManager inicializace |
| `SipkovaTulipanka.csproj` | **UPRAVEN** | CopyToOutputDirectory pro world.json |
| `CHANGES.md` | **NOVÝ** | Tento soubor |

---

## Pokrytí požadavků (set.docx)

| Požadavek | Status | Poznámka |
|-----------|--------|---------|
| Server, async, multi-klient | ✅ BYLO | MudTcpServer, async/await |
| Pohyb, místnosti, předměty | ✅ BYLO | GameWorld, Player |
| NPC, dialogy, kvíz | ✅ BYLO | Npc, Question |
| Obchod | ✅ BYLO | Shop |
| Zamčené místnosti | ✅ BYLO | HradKeys |
| **I1** – JSON světa | ✅ **NOVÉ** | world.json + LoadFromJson |
| **I2** – Logování | ✅ **NOVÉ** | Logger.cs, server.log |
| **I3** – Přihlášení, persistence | ✅ **NOVÉ** | AccountManager.cs |
| **I4** – Vlastní klient | ✅ **NOVÉ** | MudClient/ |
| **P1** – Cíl hry, výhra, statistiky | ✅ **NOVÉ** | ShowVictoryAsync, statistiky |
